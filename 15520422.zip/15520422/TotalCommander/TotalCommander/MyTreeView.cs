﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.VisualBasic.FileIO;
using System.Windows.Forms;

namespace TotalCommander
{
    class MyTreeView
    {
        const String cstDesktop = "Desktop";
        const String cstMyComputer = "MyComputer";
        const String cstMyDocuments = "MyDocuments";
        static string strTreePath;
        int intDrive;
        private TreeView treeViewControl;

        public TreeView TreeViewControl
        {
            get
            {
                return treeViewControl;
            }

            set
            {
                treeViewControl = value;
            }
        }

        public MyTreeView(TreeView tree, ImageList SmallImageList)
        {
            treeViewControl = tree;
            treeViewControl.ImageList = SmallImageList;
            InitTreeView();
            EventTreeView();
            CountDrive();
        }

        public void InitTreeView()
        {
            treeViewControl.Nodes.Clear();
            TreeNode root = new TreeNode();
            root.Name = "Desktop";
            root.Text = "Desktop";
            root.ImageIndex = 4;
            root.Tag = SpecialDirectories.Desktop;
            treeViewControl.Nodes.Add(root);

            AddMyDocuments(root);
            AddMyComputer(root);
            AddTreeViewSubFiles(root, root.Tag.ToString());

            treeViewControl.SelectedNode = root;
            strTreePath = treeViewControl.SelectedNode.Tag.ToString();
        }
        //-------------------------------------------------

        // Load Documents vao treeview
        public void AddMyDocuments(TreeNode parentNode)
        {
            TreeNode node = new TreeNode();
            node.Name = "MyDocuments";
            node.Text = "Documents";
            node.ImageIndex = 5;
            node.Tag = SpecialDirectories.MyDocuments;

            if (ExistsChildNode(node))
                node.Nodes.Add(String.Empty);

            parentNode.Nodes.Add(node);
        }
        //-------------------------------------------------

        // Load My Computer vao treeview
        public TreeNode AddMyComputer(TreeNode parentNode)
        {
            TreeNode node = new TreeNode();
            node.Name = "MyComputer";
            node.Text = "My Computer";
            node.ImageIndex = 3;
            node.Tag = cstMyComputer;
            parentNode.Nodes.Add(node);
            LoadTreeViewLogicalDrives(node);
            return node;
        }
        //-------------------------------------------------

        // Kiem tra node co node con ko /
        public bool ExistsChildNode(TreeNode node)
        {
            if (node.Tag != null)
            {
                String strParentDirectoryPath = node.Tag.ToString();
                String[] arrSubDirectories = GetSubDirectories(strParentDirectoryPath);
                if (arrSubDirectories.Length > 0)
                    return true;
            }
            return false;
        }
        //-------------------------------------------------

        // Load Drive
        public void LoadTreeViewLogicalDrives(TreeNode parentNode)
        {
            String[] arrDrives = Directory.GetLogicalDrives();
            intDrive = arrDrives.Length;
            for (int i = 0; i < arrDrives.Length; i++)
            {
                TreeNode node = new TreeNode();
                node.Text = arrDrives[i];               
                node.ImageIndex = 2;
                node.Tag = arrDrives[i];
                parentNode.Nodes.Add(node);
                if (ExistsChildNode(node))
                    node.Nodes.Add(String.Empty);
            }
        }
        //-------------------------------------------------

        // Them node vao node con
        public void AddTreeViewSubFiles(TreeNode parentNode, String strParentDirectoryPath)
        {
            String[] arrSubDirectories = GetSubDirectories(strParentDirectoryPath);
            for (int i = 0; i < arrSubDirectories.Length; i++)
            {
                DirectoryInfo info = new DirectoryInfo(arrSubDirectories[i]);
                if ((info.Attributes & FileAttributes.Hidden) == 0 && (info.Attributes & FileAttributes.Temporary) == 0)
                {
                    TreeNode node = new TreeNode();
                    node.Text = arrSubDirectories[i].Substring(strParentDirectoryPath.Length);

                    if (node.Text[0] == '\\')
                        node.Text = node.Text.Substring(1);
                    node.ImageIndex = 1;
                    node.Tag = arrSubDirectories[i];
                    parentNode.Nodes.Add(node);

                    if (ExistsChildNode(node))
                        node.Nodes.Add(String.Empty);
                }
            }
        }
        //-------------------------------------------------

        // Lay ra mang cac duong dan cua folder co trong foder duoc load
        public String[] GetSubDirectories(String strParentDirectoryPath)
        {
            if (Directory.Exists(strParentDirectoryPath))
            {
                try
                {
                    String[] arrSubDirectories = Directory.GetDirectories(strParentDirectoryPath);
                    return arrSubDirectories;
                }
                catch (Exception)
                {
                    return new String[0];
                }
            }
            return new String[0];
        }
        //-------------------------------------------------

        // load node con vao cay
        public void LoadTreeViewSubFiles(TreeNode parentNode)
        {

            if (parentNode.Tag != null)
            {
                if (parentNode.FirstNode == null || (parentNode.FirstNode != null && String.IsNullOrEmpty(parentNode.FirstNode.Text)))
                {
                    parentNode.Nodes.Clear();
                    strTreePath = parentNode.Tag.ToString();
                    AddTreeViewSubFiles(parentNode, parentNode.Tag.ToString());
                }
            }

        }
        //-------------------------------------------------

        public void ReloadTreeViewSubFiles(TreeNode parentNode)
        {
            if (parentNode.Tag != null)
            {
                parentNode.Nodes.Clear();
                if (parentNode.Text == cstDesktop)
                {
                    AddMyDocuments(parentNode);
                    AddMyComputer(parentNode);
                    AddTreeViewSubFiles(parentNode, parentNode.Tag.ToString());
                }
                else
                    AddTreeViewSubFiles(parentNode, parentNode.Tag.ToString());
            }
        }
        //-------------------------------------------------

        // load lai cay neu dua vao mot duong dan
        public void SelectNode(string strPath)
        {

            List<string> strDirectory = new List<string>();
            String[] strTemp = strPath.Split('\\');
            foreach (string temp in strTemp)
            {
                if (temp != "")
                    strDirectory.Add(temp);
            }
            string strDriver = strPath.Substring(0, 3);
            //-------------------------------
            treeViewControl.Nodes.Clear();
            TreeNode root = new TreeNode();
            root.Name = cstDesktop;
            root.Text = cstDesktop;
            root.ImageIndex = 4;           
            root.Tag = SpecialDirectories.Desktop;
            treeViewControl.Nodes.Add(root);
            AddMyDocuments(root);
            TreeNode selectNode = AddMyComputer(root);
            AddTreeViewSubFiles(root, root.Tag.ToString());
            treeViewControl.SelectedNode = selectNode;
            try
            {
                foreach (TreeNode temp in treeViewControl.SelectedNode.Nodes)
                {
                    if (temp.Tag.ToString() == strDriver)
                    {
                        treeViewControl.SelectedNode = temp;
                        break;

                    }
                }
                for (int i = 1; i < strDirectory.Count; i++)
                {
                    foreach (TreeNode treenode in treeViewControl.SelectedNode.Nodes)
                    {
                        string strnode = treenode.Tag.ToString();
                        int st = strnode.LastIndexOf('\\');
                        string strNameNode = strnode.Substring(st + 1);
                        if (strNameNode == strDirectory[i])
                        {
                            treeViewControl.SelectedNode = treenode;
                            break;
                        }
                    }
                }
            }
            catch
            {
                return;
            }
        }
        //------------------------------------------------------

        // Treeview event .
        #region Treeview Event
        public void EventTreeView()
        {

            treeViewControl.AfterExpand += new TreeViewEventHandler(TreeViewExplorer_AfterExpand);
            treeViewControl.AfterSelect += new TreeViewEventHandler(TreeViewExplorer_AfterSelect);
            treeViewControl.KeyDown += new KeyEventHandler(treeView_KeyDown);          
        }
        

        void treeView_KeyDown(object sender, KeyEventArgs e)
        {
            TreeNode node = treeViewControl.SelectedNode;
            if (e.KeyCode == Keys.Enter)
            {
                strTreePath = node.Tag.ToString();
                node.Expand();
            }
        }
        //------------------------------------------------------------

        private void TreeViewExplorer_AfterExpand(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Tag == null)
                return;
            String strDirectoryPath = e.Node.Tag.ToString();
            strTreePath = strDirectoryPath;
            if (!String.IsNullOrEmpty(strDirectoryPath))
            {
                if (!strDirectoryPath.Contains(cstMyComputer))
                {
                    LoadTreeViewSubFiles(e.Node);
                }

            }
        }
        //------------------------------------------------------------

        private void TreeViewExplorer_AfterSelect(object sender, TreeViewEventArgs e)
        {
            strTreePath = e.Node.Tag.ToString();
            e.Node.Expand();
        }
        //------------------------------------------------------------
        #endregion
        //-------------------------------------------------

        // Ham dung de ra ra duong dan cua node selected
        public string TreeGetFilePath()
        {
            return strTreePath;
        }

        // Kiem tra so luong Drives
        #region Kiem tra so luong cac o dia

        // goi su kien kiem tra o dia
        void CountDrive()
        {
            Timer t = new Timer();
            t.Interval = 40;
            t.Start();
            t.Tick += new EventHandler(t_Tick);
        }

        void t_Tick(object sender, EventArgs e)
        {
            string[] iDr = Directory.GetLogicalDrives();
            if (iDr.Length != intDrive)
            {
                SelectNode(strTreePath);
                intDrive = iDr.Length;
            }
        }

        #endregion

    }
}
