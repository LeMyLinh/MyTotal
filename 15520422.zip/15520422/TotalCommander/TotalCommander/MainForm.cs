﻿using System;
using DevComponents.DotNetBar;
using System.Windows.Forms;
using System.IO;

namespace TotalCommander
{
    public partial class MainForm : Office2007RibbonForm
    {

        #region Thuoc tinh
        MyTreeView TreeViewLeft;
        MyListView ListViewLeft;
        MyTreeView TreeViewRight;
        MyListView ListViewRight;

        FileAndFolder Item;

        #endregion

        public MainForm()
        {
            InitializeComponent();

            //Hien thi duoi dang 2 cua so tuong tac list view
            TreeViewLeft = new MyTreeView(Panel1_TreeViewLeft, TreeImageList);            
            ListViewLeft = new MyListView(Panel1_ListViewLeft, SmallImageList, Panel1_StatusLabel);

            ListViewLeft.LoadListViewSubFiles(@"C:\");
            Panel1_ComboLeft.Text = @"C:\";

            TreeViewRight = new MyTreeView(Panel2_TreeViewRight, TreeImageList);
            ListViewRight = new MyListView(Panel2_ListViewRight, SmallImageList, spc1_pan2_statusLabel);
            ListViewRight.LoadListViewSubFiles(@"D:\");
            Panel2_ComboRight.Text = @"D:\";

            TreeViewLeft.TreeViewControl.Visible = false;
            TreeViewRight.TreeViewControl.Visible = false;
            //------------------------------------------------
            Item = new FileAndFolder();

            Panel2_StatusLabel.Visible = false;
            process_shutdown.Visible = false;

            //Hien thi form giua man hinh
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            RibConMenu.SelectedRibbonTabItem = tabTools;

            ListViewLeft.ListViewControl.MouseDoubleClick += new MouseEventHandler(Panel1_LisViewLeft_MouseDoubleClick);
            ListViewRight.ListViewControl.MouseDoubleClick += new MouseEventHandler(Panel2_ListViewRight_MouseDoubleClick);

            TreeViewLeft.TreeViewControl.AfterSelect += new TreeViewEventHandler(Panel1_TreeViewLeft_AfterSelect);
            TreeViewRight.TreeViewControl.AfterSelect += new TreeViewEventHandler(Panel2_TreeViewRight_AfterSelect);

            this.Panel1_ComboLeft.Click += new EventHandler(ComboBox_Click);
            this.Panel2_ComboRight.Click += new EventHandler(ComboBox_Click);

            this.Panel1_ComboLeft.TextChanged += new EventHandler(Panel1_ComboLeft_TextChanged);
            this.Panel2_ComboRight.TextChanged += new EventHandler(Panel2_ComboRight_TextChanged);
        }

        void Panel1_LisViewLeft_MouseDoubleClick(object sender, EventArgs e)
        {
            string path = ListViewLeft.ListGetSubFilePath();
            if (Panel2_TreeViewRight.Visible)
                TreeViewRight.SelectNode(path);
        }

        void Panel2_ListViewRight_MouseDoubleClick(object sender, EventArgs e)
        {
            string path = ListViewRight.ListGetSubFilePath();
            if (Panel1_TreeViewLeft.Visible)
                TreeViewLeft.SelectNode(path);
        }

        bool DriveIsReady(string str)
        {
            if (str.Contains("MyComputer") || String.IsNullOrEmpty(str))
                return true;
            DriveInfo driveInfo = new DriveInfo(str);
            if (driveInfo.IsReady == false)
            {
                MessageBox.Show("Drive isn't ready !", "Warnning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            
            return true;
        }
        void Panel1_TreeViewLeft_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (Panel2_ListViewRight.Visible)
            {
                string path = TreeViewLeft.TreeGetFilePath();
                if (DriveIsReady(path))
                {
                    ListViewRight.LoadListViewSubFiles(path);
                }
            }
        }

        void Panel2_TreeViewRight_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (Panel1_ListViewLeft.Visible)
            {
                string path = TreeViewRight.TreeGetFilePath();
                if (DriveIsReady(path))
                {
                    ListViewLeft.LoadListViewSubFiles(path);
                }
            }
        }

        #region ComboBox
        void ComboBox_Click(object sender, EventArgs e)
        {
            ComboBox comboBox = (ComboBox)sender;
            comboBox.Items.Clear();
            comboBox.BeginUpdate();
            DriveInfo[] driveInfo = DriveInfo.GetDrives();
            foreach (DriveInfo drInfo in driveInfo)
            {
                string[] strDrive = new string[2];
                strDrive[0] = drInfo.Name;
                if (drInfo.IsReady)
                {
                    strDrive[1] = drInfo.VolumeLabel;

                }
                comboBox.Items.Add(String.Format("{0}   {1}", strDrive[0], strDrive[1]));
            }
            comboBox.EndUpdate();
        }

        private String Reload(ComboBox cb, Label lb)
        {
            ComboBox comboBox = cb;
            Label lable = lb;
            string[] strDri = Directory.GetLogicalDrives();
            foreach (string tam in strDri)
            {

                if (comboBox.Text.Contains(tam))
                {
                    try
                    {
                        DriveInfo dri = new DriveInfo(tam);
                        if (dri.IsReady == false)
                        {
                            MessageBox.Show("Drive isn't readly", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return null;
                        }
                        double total = dri.TotalSize / Math.Pow(2, 30);
                        total = Math.Round(total, 3);
                        double totalfree = dri.TotalFreeSpace / Math.Pow(2, 30);
                        totalfree = Math.Round(totalfree, 3);
                        lable.Text = "Total: " + total.ToString() + "GB     FreeSpace" + totalfree.ToString() + "GB";
                        return tam;
                    }
                    catch (Exception)
                    {
                        return null;
                    }
                }
            }
            return null;
        }

        void Panel1_ComboLeft_TextChanged(object sender, EventArgs e)
        {
            string str = Reload(this.Panel1_ComboLeft, this.Panel1_LabelLeft);
            if (str != null)
                ListViewLeft.LoadListViewSubFiles(str);
        }

        void Panel2_ComboRight_TextChanged(object sender, EventArgs e)
        {
            string str = Reload(this.Panel2_ComboRight, this.Panel2_LabelRight);
            if (str != null)
                ListViewRight.LoadListViewSubFiles(str);
        }
        #endregion

        #region Tools Menu
        private void btnNewFolder_Click(object sender, EventArgs e)
        {
            string temp;
            if (Panel1_ListViewLeft.Focused)
            {
                Item.Call(Panel1_ListViewLeft);
                string str = ListViewLeft.ListGetSubFilePath();
                Item.CreateFile(str, "New Folder", "", out temp);
                ListViewLeft.LoadListViewSubFiles(str);
                Panel1_ListViewLeft.Items[temp].Selected = true;
                Item.Rename();
            }
            if (Panel2_ListViewRight.Focused)
            {

                Item.Call(Panel2_ListViewRight);
                string str = ListViewRight.ListGetSubFilePath();
                Item.CreateFile(str, "New Folder", "", out temp);
                ListViewRight.LoadListViewSubFiles(str);
                Panel2_ListViewRight.Items[temp].Selected = true;
                Item.Rename();
            }
        }

        private void btnNewText_Click(object sender, EventArgs e)
        {
            string temp;
            if (Panel1_ListViewLeft.Focused)
            {
                Item.Call(Panel1_ListViewLeft);
                string str = ListViewLeft.ListGetSubFilePath();
                Item.CreateFile(str, "New Text", "txt", out temp);
                ListViewLeft.LoadListViewSubFiles(str);
                Panel1_ListViewLeft.Items[temp].Selected = true;
                Item.Rename();
            }
            if (Panel2_ListViewRight.Focused)
            {

                Item.Call(Panel2_ListViewRight);
                string str = ListViewRight.ListGetSubFilePath();
                Item.CreateFile(str, "New Text", "txt", out temp);
                ListViewRight.LoadListViewSubFiles(str);
                Panel2_ListViewRight.Items[temp].Selected = true;
                Item.Rename();
            }
        }

        private void btnNewWord_Click(object sender, EventArgs e)
        {
            string temp;
            if (Panel1_ListViewLeft.Focused)
            {
                Item.Call(Panel1_ListViewLeft);
                string str = ListViewLeft.ListGetSubFilePath();
                Item.CreateFile(str, "New Word", "doc", out temp);
                ListViewLeft.LoadListViewSubFiles(str);
                Panel1_ListViewLeft.Items[temp].Selected = true;
                Item.Rename();
            }
            if (Panel2_ListViewRight.Focused)
            {

                Item.Call(Panel2_ListViewRight);
                string str = ListViewRight.ListGetSubFilePath();
                Item.CreateFile(str, "New Word", "doc", out temp);
                ListViewRight.LoadListViewSubFiles(str);
                Panel2_ListViewRight.Items[temp].Selected = true;
                Item.Rename();
            }
        }

        private void btnNewExcel_Click(object sender, EventArgs e)
        {
            string temp;
            if (Panel1_ListViewLeft.Focused)
            {
                Item.Call(Panel1_ListViewLeft);
                string str = ListViewLeft.ListGetSubFilePath();
                Item.CreateFile(str, "New Excel", "xls", out temp);
                ListViewLeft.LoadListViewSubFiles(str);
                Panel1_ListViewLeft.Items[temp].Selected = true;
                Item.Rename();
            }
            if (Panel2_ListViewRight.Focused)
            {

                Item.Call(Panel2_ListViewRight);
                string str = ListViewRight.ListGetSubFilePath();
                Item.CreateFile(str, "New Excel", "xls", out temp);
                ListViewRight.LoadListViewSubFiles(str);
                Panel2_ListViewRight.Items[temp].Selected = true;
                Item.Rename();
            }
        }

        private void btnRename_Click(object sender, EventArgs e)
        {
            if (this.Panel1_ListViewLeft.Focused)
            {
                Item.Call(this.Panel1_ListViewLeft);
                Item.Rename();
            }

            if (this.Panel2_ListViewRight.Focused)
            {
                Item.Call(this.Panel2_ListViewRight);
                Item.Rename();
            }
        }

        private void btnPaste_Click(object sender, EventArgs e)
        {
            if (Panel1_ListViewLeft.Focused)
            {
                Item.Call(Panel1_ListViewLeft);
                string str = ListViewLeft.ListGetSubFilePath();
                Item.Paste(str);
                ListViewLeft.LoadListViewSubFiles(str);
            }
            if (Panel2_ListViewRight.Focused)
            {
                Item.Call(Panel2_ListViewRight);
                string str = ListViewRight.ListGetSubFilePath();
                Item.Paste(str);
                ListViewRight.LoadListViewSubFiles(str);
            }
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            if (Panel1_ListViewLeft.Focused)
            {
                Item.Call(Panel1_ListViewLeft);
                Item.Copy();
                if (Panel2_ListViewRight.Visible)
                {
                    string str = ListViewRight.ListGetSubFilePath();
                    Item.Paste(str);
                    ListViewRight.LoadListViewSubFiles(str);
                }
            }
            if (Panel2_ListViewRight.Focused)
            {
                Item.Call(Panel2_ListViewRight);
                Item.Copy();
                if (Panel1_ListViewLeft.Visible)
                {
                    string str = ListViewLeft.ListGetSubFilePath();
                    Item.Paste(str);
                    ListViewLeft.LoadListViewSubFiles(str);
                }
            }
        }

        private void btnCut_Click(object sender, EventArgs e)
        {
            if (Panel1_ListViewLeft.Focused)
            {
                Item.Call(Panel1_ListViewLeft);
                Item.Cut();
                if (Panel2_ListViewRight.Visible)
                {
                    string str = ListViewRight.ListGetSubFilePath();
                    Item.Paste(str);
                    ListViewRight.LoadListViewSubFiles(str);
                }
            }
            if (Panel2_ListViewRight.Focused)
            {
                Item.Call(Panel2_ListViewRight);
                Item.Cut();
                if (Panel1_ListViewLeft.Visible)
                {
                    string str = ListViewLeft.ListGetSubFilePath();
                    Item.Paste(str);
                    ListViewLeft.LoadListViewSubFiles(str);
                }
            }
        }

        private void btnCopyToFolder_Click(object sender, EventArgs e)
        {
            if (Panel1_ListViewLeft.Focused)
            {
                Item.Call(Panel1_ListViewLeft);
                Item.Copy();               
                fbdFolderDialog.ShowDialog();
                string str = fbdFolderDialog.SelectedPath;
                Item.Paste(str);
            }
            if (Panel2_ListViewRight.Focused)
            {
                Item.Call(Panel2_ListViewRight);
                Item.Copy();
                fbdFolderDialog.ShowDialog();
                string str = fbdFolderDialog.SelectedPath;
                Item.Paste(str);
            }
        }

        private void btnMoveToFolder_Click(object sender, EventArgs e)
        {
            if (Panel1_ListViewLeft.Focused)
            {
                Item.Call(Panel1_ListViewLeft);
                Item.Copy();
                fbdFolderDialog.ShowDialog();
                string str = fbdFolderDialog.SelectedPath;
                Item.Paste(str);
                str = ListViewLeft.ListGetSubFilePath();
                ListViewLeft.LoadListViewSubFiles(str);
            }
            if (Panel2_ListViewRight.Focused)
            {
                Item.Call(Panel2_ListViewRight);
                Item.Copy();
                fbdFolderDialog.ShowDialog();
                string str = fbdFolderDialog.SelectedPath;
                Item.Paste(str);
                str = ListViewRight.ListGetSubFilePath();
                ListViewRight.LoadListViewSubFiles(str);
            }
        }

        private void btnRecycle_Click(object sender, EventArgs e)
        {
            if (Panel1_ListViewLeft.Focused)
            {
                Item.Call(Panel1_ListViewLeft);
                string str = ListViewLeft.ListGetSubFilePath();
                Item.DeleteToRecycleBin();
                ListViewLeft.LoadListViewSubFiles(str);
            }
            if (Panel2_ListViewRight.Focused)
            {
                Item.Call(Panel2_ListViewRight);
                string str = ListViewRight.ListGetSubFilePath();
                Item.DeleteToRecycleBin();
                ListViewRight.LoadListViewSubFiles(str);
            }
        }

        private void btnPerDel_Click(object sender, EventArgs e)
        {
            if (Panel1_ListViewLeft.Focused)
            {
                Item.Call(Panel1_ListViewLeft);
                string str = ListViewLeft.ListGetSubFilePath();
                Item.DeletePermanently();
                ListViewLeft.LoadListViewSubFiles(str);
            }
            if (Panel2_ListViewRight.Focused)
            {
                Item.Call(Panel2_ListViewRight);
                string str = ListViewRight.ListGetSubFilePath();
                Item.DeletePermanently();
                ListViewRight.LoadListViewSubFiles(str);
            }
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            if (this.Panel1_ListViewLeft.Focused)
            {
                Item.Call(this.Panel1_ListViewLeft);
                Item.AddPath(ListViewLeft.ListGetSubFilePath());
            }

            if (this.Panel2_ListViewRight.Focused)
            {
                Item.Call(this.Panel2_ListViewRight);
                Item.AddPath(ListViewRight.ListGetSubFilePath());
            }

            Item.Find();
        }

        #endregion

        #region Key Event of ListView
        private void Panel1_ListViewLeft_KeyDown(object sender, KeyEventArgs e)
        {
            string str = ListViewLeft.ListGetSubFilePath();
            Item.Call(this.Panel1_ListViewLeft);
            bool flag = false;

            if (e.Control)
            {
                switch (e.KeyCode)
                {
                    case Keys.C: Item.Copy(); break;
                    case Keys.X: Item.Cut(); break;
                    case Keys.V: Item.Paste(str); flag = true; break;
                    default:
                        return;
                }
            }

            if (e.Shift)
            {
                switch (e.KeyCode)
                {
                    case Keys.C: Item.Copy(); break;
                    case Keys.X: Item.Cut(); break;
                    case Keys.Delete:
                        {
                            Item.DeletePermanently();
                            ListViewLeft.LoadListViewSubFiles(str);
                            break;
                        }
                    default: return;
                }
                if ((e.KeyCode == Keys.C || e.KeyCode == Keys.X) && this.Panel2_ListViewRight.Visible)
                {
                    Item.Call(this.Panel2_ListViewRight);
                    string  desPath = ListViewRight.ListGetSubFilePath();
                    Item.Paste(desPath);
                    ListViewRight.LoadListViewSubFiles(desPath);
                }
            }

            switch (e.KeyCode)
            {
                case Keys.F2: Item.Rename(); break;
                case Keys.F5:
                    {
                        Item.Copy();
                        fbdFolderDialog.ShowDialog();
                        string path = fbdFolderDialog.SelectedPath;
                        Item.Paste(path);
                        break;
                    }
                case Keys.F6:
                    {
                        Item.Cut();
                        fbdFolderDialog.ShowDialog();
                        string path = fbdFolderDialog.SelectedPath;
                        Item.Paste(path);
                        flag = true;
                        break;
                    }
                case Keys.Delete:
                    Item.DeleteToRecycleBin();
                    break;                            
            }

            if (flag)
                ListViewLeft.LoadListViewSubFiles(str);
        }

        private void Panel2_ListViewRight_KeyDown(object sender, KeyEventArgs e)
        {
            string str = ListViewRight.ListGetSubFilePath();
            Item.Call(this.Panel2_ListViewRight);
            bool flag = false;

            if (e.Control)
            {
                switch (e.KeyCode)
                {
                    case Keys.C: Item.Copy(); break;
                    case Keys.X: Item.Cut(); break;
                    case Keys.V: Item.Paste(str); flag = true; break;
                    default:
                        return;
                }
            }

            if (e.Shift)
            {
                switch (e.KeyCode)
                {
                    case Keys.C: Item.Copy(); break;
                    case Keys.X: Item.Cut(); break;
                    case Keys.Delete:
                        {
                            Item.DeletePermanently();
                            ListViewRight.LoadListViewSubFiles(str);
                            break;
                        }
                    default: return;
                }
                if ((e.KeyCode == Keys.C || e.KeyCode == Keys.X) && this.Panel1_ListViewLeft.Visible)
                {
                    Item.Call(this.Panel1_ListViewLeft);
                    string desPath = ListViewLeft.ListGetSubFilePath();
                    Item.Paste(desPath);
                    ListViewLeft.LoadListViewSubFiles(desPath);
                }
            }

            switch (e.KeyCode)
            {
                case Keys.F2: Item.Rename(); break;
                case Keys.F5:
                    {
                        Item.Copy();
                        fbdFolderDialog.ShowDialog();
                        string path = fbdFolderDialog.SelectedPath;
                        Item.Paste(path);
                        break;
                    }
                case Keys.F6:
                    {
                        Item.Cut();
                        fbdFolderDialog.ShowDialog();
                        string path = fbdFolderDialog.SelectedPath;
                        Item.Paste(path);
                        flag = true;
                        break;
                    }
                case Keys.Delete:
                    Item.DeleteToRecycleBin();
                    break;
            }

            if (flag)
                ListViewRight.LoadListViewSubFiles(str);
        }

        #endregion

        #region View Menu
        private void btnListView_Click(object sender, EventArgs e)
        {
            if (this.Panel1_TreeViewLeft.Focused)
            {
                this.Panel1_TreeViewLeft.Visible = false;
                this.Panel1_ListViewLeft.Visible = true;
            }

            if (this.Panel2_TreeViewRight.Focused)
            {
                this.Panel2_TreeViewRight.Visible = false;
                this.Panel2_ListViewRight.Visible = true;
            }
        }

        private void btnTreeView_Click(object sender, EventArgs e)
        {
            if (this.Panel1_ListViewLeft.Focused)
            {
                this.Panel1_ListViewLeft.Visible = false;
                this.Panel1_TreeViewLeft.Visible = true;
            }

            if (this.Panel2_ListViewRight.Focused)
            {
                this.Panel2_ListViewRight.Visible = false;
                this.Panel2_TreeViewRight.Visible = true;
            }
        }

        private void btnLargeIcon_Click(object sender, EventArgs e)
        {
            if (this.Panel1_ListViewLeft.Focused)
            {
                ListViewLeft.ListViewControl.LargeImageList = this.LargeImageList;
                ListViewLeft.ListViewControl.View = View.LargeIcon;
            }
            if (this.Panel2_ListViewRight.Focused)
            {
                ListViewRight.ListViewControl.LargeImageList = this.LargeImageList;
                ListViewRight.ListViewControl.View = View.LargeIcon;
            }
        }

        private void btnSmallIcon_Click(object sender, EventArgs e)
        {
            if (this.Panel1_ListViewLeft.Focused)
                ListViewLeft.ListViewControl.View = View.SmallIcon;

            if (this.Panel2_ListViewRight.Focused)
                ListViewRight.ListViewControl.View = View.SmallIcon;
        }

        private void btnListLayout_Click(object sender, EventArgs e)
        {
            if (this.Panel1_ListViewLeft.Focused)
                ListViewLeft.ListViewControl.View = View.List;

            if (this.Panel2_ListViewRight.Focused)
                ListViewRight.ListViewControl.View = View.List;
        }


        #endregion

        #region Drag Drop
        private void MainForm_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] filePaths = (string[])(e.Data.GetData(DataFormats.FileDrop));
                foreach (string fileLoc in filePaths)
                {
                    if (File.Exists(fileLoc))
                    {

                    }
                }
            }
        }

        private void MainForm_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }

        }

        #endregion

        private void buttonItem13_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCmd_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("cmd");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở ứng dụng chọn. Lỗi trả về là: \n" + ex.Message, " Lỗi thực thi...", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void btnTaskManage_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("taskmgr");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở ứng dụng chọn. Lỗi trả về là: \n" + ex.Message, " Lỗi thực thi...", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

        }

        private void btnNotepad_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("notepad.exe");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể mở ứng dụng chọn. Lỗi trả về là: \n" + ex.Message, " Lỗi thực thi...", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private About.About formabout;
        private void btnInfor_Click(object sender, EventArgs e)
        {
            formabout = new About.About();
            formabout.Show();
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {

        }
    }
}
