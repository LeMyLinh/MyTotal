﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualBasic.FileIO;
using System.Drawing;

namespace TotalCommander
{
    class FileAndFolder
    {     
        private List<String> CopiedFilesList = new List<string>();
        private List<String> CutFilesList = new List<string>();
        private string strOldName;
        private string FileAction;
        private string cstActionCopy = "Copy";
        private string cstActionCut = "Cut";
        private ListView listView;
        private string strFind;

        // khai bao form Search
        Form frmFind = new Form();
        Label lableOfFind = new Label();
        Button btnFind = new Button();
        TextBox txtFindPath = new TextBox();

        public void Call(ListView lv)
        {
            listView = lv;
            listView.AfterLabelEdit += new LabelEditEventHandler(listView_AfterLabelEdit);
            btnFind.Click += new EventHandler(btnFind_Click);
        }


        void listView_AfterLabelEdit(object sender, LabelEditEventArgs e)
        {
            try
            {
                if (e.Label != null)
                {
                    ListViewItem item = listView.Items[strOldName];

                    if (item.Tag != null)
                    {
                        string strtemp = item.Tag.ToString();
                        int ipos = strtemp.LastIndexOf('\\');
                        String strNewName = String.Format("{0}\\{1}", strtemp.Substring(0, ipos), e.Label);
                        if (Directory.Exists(strNewName) && File.Exists(strNewName))
                        {
                            MessageBox.Show("Ten da ton tai", "Loi", MessageBoxButtons.OK);
                            item.Text = strOldName;
                            return;
                        }
                        FileInfo info = new FileInfo(strNewName);
                        if ((info.Attributes & FileAttributes.Directory) == FileAttributes.Directory)
                            FileSystem.RenameDirectory(item.Tag.ToString(), e.Label);
                        else
                            FileSystem.RenameFile(item.Tag.ToString(), e.Label);
                        item.Tag = strNewName;

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Ham copy
        public void Copy()
        {
            FileAction = cstActionCopy;
            CopiedFilesList.Clear();
            if (listView.SelectedItems.Count > 0)
            {
                foreach (ListViewItem item in listView.SelectedItems)
                    if (item.Tag != null)
                        CopiedFilesList.Add(item.Tag.ToString());
            }
        }

        // Ham Cut
        public void Cut()
        {
            FileAction = cstActionCut;
            CutFilesList.Clear();
            foreach (ListViewItem item in listView.SelectedItems)
            {
                if (item.Tag != null)
                {
                    CutFilesList.Add(item.Tag.ToString());

                }

            }
        }

        // Ham Paste
        public void Paste(String strDestinationPath)
        {
            try
            {
                if (FileAction == cstActionCut)
                {
                    foreach (String strSourceFile in CutFilesList)
                    {
                        String strDestFile = String.Format("{0}\\{1}", strDestinationPath, Path.GetFileName(strSourceFile));
                        FileInfo info = new FileInfo(strSourceFile);
                        if ((info.Attributes & FileAttributes.Directory) == FileAttributes.Directory)
                            FileSystem.MoveDirectory(strSourceFile, strDestFile, UIOption.AllDialogs, UICancelOption.DoNothing);
                        else
                            FileSystem.MoveFile(strSourceFile, strDestFile, UIOption.AllDialogs, UICancelOption.DoNothing);
                        FileInfo DelFile = new FileInfo(strSourceFile);
                        DelFile.Delete();
                    }
                }
                else
                    if (FileAction == cstActionCopy)
                {
                    foreach (String strSourceFile in CopiedFilesList)
                    {
                        String strDestFile = String.Format("{0}\\{1}", strDestinationPath, Path.GetFileName(strSourceFile));
                        FileInfo info = new FileInfo(strSourceFile);
                        if ((info.Attributes & FileAttributes.Directory) == FileAttributes.Directory)
                            FileSystem.CopyDirectory(strSourceFile, strDestFile, UIOption.AllDialogs, UICancelOption.DoNothing);
                        else
                            FileSystem.CopyFile(strSourceFile, strDestFile, UIOption.AllDialogs, UICancelOption.DoNothing);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Ham ReName.
        public void Rename()
        {
            if (listView.SelectedItems.Count > 0)
            {
                ListViewItem item = listView.SelectedItems[0];
                if (item != null)
                {
                    strOldName = item.Text;
                    item.BeginEdit();
                }

            }
        }

        //Ham Delete hoan toan

        public Boolean DeletePermanently()
        {
            try
            {
                if (listView.SelectedItems.Count > 0)
                {
                    if (MessageBox.Show("Do you want permanently delete " + listView.SelectedItems.Count.ToString() + "item", "Delete", MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {

                        foreach (ListViewItem item in listView.SelectedItems)
                        {
                            string path = item.Tag.ToString();
                            DirectoryInfo info = new DirectoryInfo(path);

                            if ((info.Attributes | FileAttributes.Directory) == info.Attributes)
                                FileSystem.DeleteDirectory(path, UIOption.OnlyErrorDialogs, RecycleOption.DeletePermanently, UICancelOption.DoNothing);
                            else
                                FileSystem.DeleteFile(path, UIOption.OnlyErrorDialogs, RecycleOption.DeletePermanently, UICancelOption.DoNothing);
                        }
                        return true;
                    }
                }
            }
            catch (System.Exception)
            {
                return false;
            }
            return false;
        }
        // Ham Delete toi RecycleBin
        public Boolean DeleteToRecycleBin()
        {
            try
            {
                if (listView.SelectedItems.Count > 0)
                {
                    if (MessageBox.Show("Do you want delete to RecycleBin " + listView.SelectedItems.Count.ToString() + "item", "Delete", MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {

                        foreach (ListViewItem item in listView.SelectedItems)
                        {
                            string path = item.Tag.ToString();
                            DirectoryInfo info = new DirectoryInfo(path);

                            if ((info.Attributes | FileAttributes.Directory) == info.Attributes)
                                FileSystem.DeleteDirectory(path, UIOption.OnlyErrorDialogs, RecycleOption.SendToRecycleBin, UICancelOption.DoNothing);
                            else
                                FileSystem.DeleteFile(path, UIOption.OnlyErrorDialogs, RecycleOption.SendToRecycleBin, UICancelOption.DoNothing);
                        }
                        return true;
                    }
                }
            }
            catch (System.Exception)
            {
                return false;
            }
            return false;
        }

        #region Find
        //ham nhan duong link
        public void AddPath(string s)
        {
            strFind = s;
        }
        // ham search

        public void Find()
        {
            frmFind.Size = new Size(300, 100);
            frmFind.StartPosition = FormStartPosition.CenterParent;

            lableOfFind.Size = new Size(70, 20);
            lableOfFind.Text = "File Name: ";
            lableOfFind.Location = new Point(-3, 8);

            txtFindPath.Size = new Size(170, 20);
            txtFindPath.Location = new Point(70, 5);

            btnFind.Size = new Size(37, 22);
            btnFind.Text = "GO";
            btnFind.Location = new Point(245, 3);
            txtFindPath.KeyDown += new KeyEventHandler(txtFindPath_KeyDown);

            frmFind.Controls.Add(lableOfFind);

            frmFind.Controls.Add(txtFindPath);

            frmFind.Controls.Add(btnFind);

            frmFind.ShowDialog();

        }

        // Textbox event keydown.
        void txtFindPath_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnFind_Click(sender, e);
            }
        }

        // Button Find event click
        void btnFind_Click(object sender, EventArgs e)
        {

            listView.Items.Clear();

            List<String> strList = new List<string>();
            string s_Search = txtFindPath.Text;
            string[] temp1 = Directory.GetFiles(strFind);

            foreach (string i in temp1)
            {
                int iPos = i.LastIndexOf('\\');
                string tam = i.Substring(iPos + 1);
                if (i.Contains(s_Search))
                    strList.Add(i);
            }
            string[] temp2 = Directory.GetDirectories(strFind);
            foreach (string i in temp2)
            {
                int iPos = i.LastIndexOf('\\');
                string tam = i.Substring(iPos + 1);
                if (tam.Contains(s_Search))
                    strList.Add(i);
            }
            if (strList.Count == 0)
            {
                ListViewItem item = new ListViewItem();
                item.ImageKey = "Undo.png";
                item.Tag = strFind;
                item.Text = " Find not";
                listView.Items.Add(item);
                frmFind.Close();

            }
            // Load ket qua tim duoc vao listview
            foreach (string str in strList)
            {
                ListViewItem item = new ListViewItem();
                item.Tag = str;
                item.Name = str;
                item.Text = str;
                DirectoryInfo temp = new DirectoryInfo(str);
                
                if (temp.Attributes == FileAttributes.Directory)
                    item.ImageKey = "blueFolder.jpg";
                else
                {
                    Icon icon = Icon.ExtractAssociatedIcon(str);
                    listView.LargeImageList.Images.Add(temp.Extension, icon);
                    item.ImageIndex = listView.LargeImageList.Images.Count - 1;

                }
                listView.Items.Add(item);
            }

            frmFind.Close();

        }

        #endregion

        // Ham New
        public void CreateFile(String strDestinationPath, String strTemplateName, String strExtension, out String strPath)
        {
            strPath = "";
            if (String.IsNullOrEmpty(strExtension))
            {
                if (!String.IsNullOrEmpty(strDestinationPath))
                {
                    String strNewFolderName = String.Empty;
                    int i = 0;
                    do
                    {
                        if (strDestinationPath.Length == 3)
                            strDestinationPath = strDestinationPath.Substring(0, 2);
                        if (i == 0)
                            strNewFolderName = String.Format("{0}\\{1}", strDestinationPath, strTemplateName);
                        else
                            strNewFolderName = String.Format("{0}\\{1}{2}", strDestinationPath, strTemplateName, i);
                        i++;
                    } while (Directory.Exists(strNewFolderName));
                    FileSystem.CreateDirectory(strNewFolderName);
                    strPath = strNewFolderName;
                }
            }
            else
            {

                if (strDestinationPath.Length == 3)
                    strDestinationPath = strDestinationPath.Substring(0, 2);
                if (!String.IsNullOrEmpty(strDestinationPath))
                {
                    int i = 0;
                    String strNewFileName = String.Empty;
                    do
                    {

                        if (i == 0)
                            strNewFileName = String.Format("{0}\\{1}.{2}", strDestinationPath, strTemplateName, strExtension);
                        else
                            strNewFileName = String.Format("{0}\\{1}{2}.{3}", strDestinationPath, strTemplateName, i, strExtension);
                        i++;
                    } while (System.IO.File.Exists(strNewFileName));
                    FileStream fileCreate = System.IO.File.Create(strNewFileName);
                    strPath = strNewFileName;
                }
            }
        }
    }
}


