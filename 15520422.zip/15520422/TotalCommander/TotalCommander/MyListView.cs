﻿using System;
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualBasic.FileIO;
using System.Drawing;
using GongSolutions.Shell;

namespace TotalCommander
{
    class MyListView
    {
        private const String cstDesktop = "Desktop";
        private const String cstMyComputer = "MyComputer";
        private const String cstMyDocuments = "MyDocuments";
        private string strPathDirectory;
        static string[] strDrapdrog = new string[10];
        
        private ListView listViewControl;
        private ToolStripStatusLabel StatusLabel;

        public ListView ListViewControl
        {
            get
            {
                return listViewControl;
            }

            set
            {
                listViewControl = value;
            }
        }

        public MyListView(ListView lv, ImageList Smallimagelist, ToolStripStatusLabel lb)
        {
            strPathDirectory = @"C:\";
            listViewControl = lv;
            listViewControl.SmallImageList = Smallimagelist;
            StatusLabel = lb;
            EventListView();
            listViewControl.MultiSelect = true;
            listViewControl.View = View.List;
            lv.AllowDrop = true;
        }

       

        // Load listview va treeview
        #region Loadlistview

        public String[] GetSubFiles(String strParentDirectoryPath)
        {
            if (Directory.Exists(strParentDirectoryPath))
            {
                try
                {
                    String[] arrSubFiles = Directory.GetFiles(strParentDirectoryPath);
                    return arrSubFiles;
                }
                catch (Exception)
                {
                    return new String[0];
                }
            }
            return new String[0];
        }
        //------------------------------------------------------------
        public String[] GetSubDirectories(String strParentDirectoryPath)
        {
            if (Directory.Exists(strParentDirectoryPath))
            {
                try
                {
                    String[] arrSubFiles = Directory.GetDirectories(strParentDirectoryPath);
                    return arrSubFiles;
                }
                catch (Exception)
                {
                    return new String[0];
                }
            }
            return new String[0];
        }
        //-----------------------------------------------------------
        public void LoadListViewLogicalDrives()
        {
            listViewControl.Items.Clear();

            string[] arrDrives = Directory.GetLogicalDrives();

            for (int i = 0; i < arrDrives.Length; i++)
            {
                ListViewItem item = new ListViewItem();
                item.Text = arrDrives[i];
                item.Tag = arrDrives[i];
                item.ImageIndex = 15;           
                                
                listViewControl.Items.Add(item);
            }
        }
        //-----------------------------------------------------------
        public void LoadListViewSubFiles(String strParentDirectoryPath)
        {

            listViewControl.Items.Clear();

            String[] arrSubDirectories = GetSubDirectories(strParentDirectoryPath);

            if (TestDrive(strParentDirectoryPath) == false)
            {
                if (strParentDirectoryPath.Contains(cstMyComputer))
                {
                    LoadListViewLogicalDrives();
                    return;
                }
                int iPos = strParentDirectoryPath.LastIndexOf('\\');
                if (iPos > 0 && iPos < 3)
                    iPos = 3;
                String strback = strParentDirectoryPath.Substring(0, iPos);
                ListViewItem backitem = new ListViewItem();
                backitem.Text = "...";
                backitem.ImageIndex = 19;
               
                backitem.Tag = strback;
                backitem.Name = strback;
                listViewControl.Items.Add(backitem);
            }
            else
            {
                DriveInfo driveInfo = new DriveInfo(strParentDirectoryPath);
                if (driveInfo.IsReady == false)
                {
                    return;
                }
            }
            for (int i = 0; i < arrSubDirectories.Length; i++)
            {
                DirectoryInfo info = new DirectoryInfo(arrSubDirectories[i]);
                if ((info.Attributes & FileAttributes.Hidden) == 0 && (info.Attributes & FileAttributes.Temporary) == 0)
                {
                    ListViewItem item = new ListViewItem();
                    item.Text = arrSubDirectories[i].Substring(strParentDirectoryPath.Length);
                    item.Tag = arrSubDirectories[i];
                    if (item.Text[0] == '\\')
                        item.Text = item.Text.Substring(1);
                    item.ImageIndex = 14;
                   
                    item.Name = item.Tag.ToString();
                    listViewControl.Items.Add(item);
                }
            }
            if (listViewControl.Items.Count > 0)
            {
                strPathDirectory = strParentDirectoryPath;
            }
           

            String[] arrSubFiles = GetSubFiles(strParentDirectoryPath);

            for (int i = 0; i < arrSubFiles.Length; i++)
            {
                FileInfo info = new FileInfo(arrSubFiles[i]);

                if ((info.Attributes & FileAttributes.Hidden) == 0 && (info.Attributes & FileAttributes.Temporary) == 0)
                {
                    String strFilePath = FormatPathString(arrSubFiles[i]);
                    //Icon icon = Icon.ExtractAssociatedIcon(strFilePath);
                    //listViewControl.LargeImageList.Images.Add(info.Extension, icon);
                    //listViewControl.SmallImageList.Images.Add(info.Extension, icon);

                    ListViewItem item = new ListViewItem();
                    item.Text = arrSubFiles[i].Substring(strParentDirectoryPath.Length);
                    if (item.Text[0] == '\\')
                        item.Text = item.Text.Substring(1);
                    //item.ImageIndex = listViewControl.LargeImageList.Images.Count - 1;
                    item.ImageIndex = GetImageIndex(info);
                    item.Tag = arrSubFiles[i];
                    item.Name = item.Tag.ToString();

                    listViewControl.Items.Add(item);
                }
            }

            Label();
        }
        //-----------------------------------------------------------

        public int GetImageIndex(FileInfo file)
        {
            switch (file.Extension.ToUpper())
            {
                case ".TXT":
                case ".DIZ":
                case ".LOG":
                    return 0;
                case ".PDF":
                    return 1;
                case ".HTM":
                case ".HTML":
                    return 2;
                case ".DOC":
                case ".DOCX":
                    return 3;
                case ".EXE":
                    return 4;
                case ".JPG":
                case ".PNG":
                case ".BMP":
                case ".GIF":
                    return 5;
                case ".MP3":
                case ".WAV":
                case ".WMV":
                case ".ASF":
                case ".MPEG":
                case ".AVI":
                    return 6;
                case ".RAR":
                case ".ZIP":
                    return 7;
                case ".PPT":
                case ".PPTX":
                    return 8;
                case ".MDB":
                    return 9;
                case ".XLS":
                case ".XLSX":
                    return 10;
                case ".MP4":
                case ".FLV":
                case ".SWF":
                case ".FLA":
                    return 11;
                default:
                    return 12;
            }
        }

        //-----------------------------------------------------------
        public bool TestDrive(string strSubDirectory)
        {
            string[] strDrive = Directory.GetLogicalDrives();
            foreach (string strdrive in strDrive)
            {
                if (strdrive == strSubDirectory)
                {
                    return true;
                }
            }
            return false;
        }
        //-----------------------------------------------------------
        public void OpenFile(String strPath)
        {
            try
            {
                FileInfo info = new FileInfo(strPath);
                if ((info.Attributes & FileAttributes.Directory) == FileAttributes.Directory)
                {
                    LoadListViewSubFiles(strPath);
                }
                else
                    System.Diagnostics.Process.Start(strPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        //-----------------------------------------------------------
        private String FormatPathString(String strPath)
        {
            String result = strPath;
            int index = strPath.IndexOf('\\');
            if (index + 1 < strPath.Length - 1)
                if (strPath[index + 1] == '\\')
                    result = strPath.Remove(index, 1);
            return result;
        }
        //----------------------------------------------------------
        public ListViewItem GetListViewSelectedItem()
        {
            if (listViewControl.SelectedItems.Count > 0)
                return listViewControl.SelectedItems[0];
            return null;
        }
        //----------------------------------------------------------
        void Label()
        {
            try
            {
                string[] str1 = Directory.GetDirectories(strPathDirectory);
                string[] str2 = Directory.GetFiles(strPathDirectory);
                int ipos = strPathDirectory.LastIndexOf('\\') + 1;
                StatusLabel.Text = "[" + strPathDirectory.Substring(ipos) + "]    \t" + str1.Length.ToString() + " Folders    \t" + str2.Length.ToString() + " Files.";
            }
            catch (Exception)
            {
                return;
            }
        }
        //----------------------------------------------------------
        #endregion
        // ---------------------------------------

        // Lay link cua listview

        #region Ham dung de get duong dan tu listview

        // Ham dung de lay dung dan cua folder dang duoc load .
        public String ListGetSubFilePath()
        {
            return strPathDirectory;
        }

        // Ham dung de xac dinh duong dan cua item dang duoc chon trong listview

        #endregion

        // ----------------------------------------

        // ListView Event

        #region listview event
        public void EventListView()
        {
            listViewControl.MouseDoubleClick += new MouseEventHandler(ListViewShow_MouseDoubleClick);
            listViewControl.AfterLabelEdit += new LabelEditEventHandler(ListViewShow_AfterLabelEdit);
            listViewControl.KeyDown += new KeyEventHandler(ListViewShow_KeyDown);
            listViewControl.Click += new EventHandler(listView_Click);

            //               Dragdrop
            listViewControl.DragEnter += new DragEventHandler(listView_DragEnter);
            listViewControl.DragDrop += new DragEventHandler(listView_DragDrop);
            listViewControl.ItemDrag += new ItemDragEventHandler(listView_ItemDrag);
            //listView.MouseDown += new MouseEventHandler(listView_MouseDown);
        }


        // code dragdrop trong listview
        #region Dragdrop

        void listView_ItemDrag(object sender, ItemDragEventArgs e)
        {
            listViewControl.DoDragDrop(listViewControl.SelectedItems[0].Tag.ToString(), DragDropEffects.Copy);
        }


        // -----------------------------------------------------------
        void listView_DragDrop(object sender, DragEventArgs e)
        {
            ListView lv = (ListView)sender;

            // Tra ve dia chi cua tro chuot tren ListView control.
            Point cp = lv.PointToClient(new Point(e.X, e.Y));

            // Obtain the item that is located at the specified location of the mouse pointer.
            ListViewItem dragToItem = lv.GetItemAt(cp.X, cp.Y);
            if (dragToItem == null)
            {
                return;
            }

            string dich = dragToItem.Tag.ToString();
            DirectoryInfo dri = new DirectoryInfo(dich);

            // Khai bao bien chuoi chua duong dan chua file dich.
            string dich1 = Path.GetDirectoryName(dich);

            string s = (string)e.Data.GetData(DataFormats.Text);

            DirectoryInfo dir = new DirectoryInfo(s);
            string tenFile = "\\" + Path.GetFileName(s);


            // Neu thu muc keo tha den la mot file.
            if (dri.Attributes != FileAttributes.Directory)
            {
                dich1 = dich1 + "\\" + Path.GetFileName(s);

                if (dir.Attributes == FileAttributes.Directory)
                {
                    FileSystem.CopyDirectory(s, dich1, UIOption.AllDialogs);
                }
                else
                {
                    FileSystem.CopyFile(s, dich1, UIOption.AllDialogs);
                }
                LoadListViewSubFiles(Path.GetDirectoryName(dich1));
            }
            else
            {
                dich = dich + tenFile;
                if (dir.Attributes == FileAttributes.Directory)
                {
                    FileSystem.CopyDirectory(s, dich, UIOption.AllDialogs);
                    LoadListViewSubFiles(dri.ToString());
                }
                else
                {
                    FileSystem.CopyFile(s, dich, UIOption.AllDialogs);
                }
            }

        }
        // -----------------------------------------------------------
        void listView_DragEnter(object sender, DragEventArgs e)
        {

            e.Effect = DragDropEffects.Copy;
        }
        //----------------------------------------------------------
        #endregion

        // code ve su kien key va mouse trong listview
        #region Cac su kien khac


        void listView_Click(object sender, EventArgs e)
        {
            try
            {
                int ipos = listViewControl.SelectedItems[0].Name.LastIndexOf('\\');
                if (ipos == 2)
                    ipos = 3;
                strPathDirectory = listViewControl.Items[0].Tag.ToString().Substring(0, ipos);
            }
            catch (Exception)
            {
                return;
            }

        }
        //-------------------------------------------------------------
        private void ListViewShow_AfterLabelEdit(object sender, LabelEditEventArgs e)
        {
            try
            {
                if (e.Label != null)
                {
                    ListViewItem item = listViewControl.Items[e.Item];
                    int iPos = item.Tag.ToString().LastIndexOf('\\');
                    string strPath = item.Tag.ToString().Substring(0, iPos);
                    if (item.Tag != null)
                    {
                        String strNewName = String.Format("{0}\\{1}", strPath, e.Label);
                        FileInfo info = new FileInfo(item.Tag.ToString());
                        if ((info.Attributes & FileAttributes.Directory) == FileAttributes.Directory)
                            FileSystem.RenameDirectory(item.Tag.ToString(), e.Label);
                        else
                            FileSystem.RenameFile(item.Tag.ToString(), e.Label);
                        item.Tag = strNewName;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        //-------------------------------------------------------------
        private void ListViewShow_KeyDown(object sender, KeyEventArgs e)
        {
            if (listViewControl.SelectedItems.Count > 0)
            {
                if (e.KeyCode == Keys.Enter)
                {
                    ListViewItem item = listViewControl.SelectedItems[0];
                    strPathDirectory = item.Tag.ToString();
                    OpenFile(item.Tag.ToString());
                }
            }
        }
        //---------------------------------------------------------------
        private void ListViewShow_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {

                if (listViewControl.SelectedItems.Count > 0)
                {
                    ListViewItem item = listViewControl.SelectedItems[0];
                    if (item.Tag != null)
                    {
                        string s = item.Tag.ToString();
                        OpenFile(s);
                    }
                }

            }
        }        

        //-------------------------------------------------------------
        #endregion
        #endregion

        // ----------------------------------------

        // Ham dung de xac dinh cot khi hien thi dang detail cua listview
        public void ViewDetails()
        {
            listViewControl.Items.Clear();
            listViewControl.Columns.Clear();
            try
            {
                String[] stringfolderName = Directory.GetDirectories(strPathDirectory);
                foreach (string folderName in stringfolderName)
                {
                    FileInfo folderinfo = new FileInfo(folderName);
                    if ((folderinfo.Attributes & FileAttributes.Hidden) == 0 && (folderinfo.Attributes & FileAttributes.Temporary) == 0)
                    {
                        String[] lvfolder = new String[3];
                        String[] nfolder = folderinfo.FullName.Split('\\');
                        lvfolder[0] = nfolder[nfolder.Length - 1];
                        lvfolder[1] = folderinfo.CreationTime.ToShortDateString();
                        lvfolder[2] = folderinfo.LastWriteTime.ToShortDateString();

                        ListViewItem itemfolder = new ListViewItem(lvfolder);
                        listViewControl.Items.Add(itemfolder);
                        itemfolder.ImageIndex = 0;
                        listViewControl.Sorting = SortOrder.Ascending;
                    }
                }
                while (listViewControl.LargeImageList.Images.Count > 3)
                    listViewControl.LargeImageList.Images.RemoveAt(listViewControl.LargeImageList.Images.Count - 1);
                String[] stringfileName = Directory.GetFiles(strPathDirectory);
                foreach (string fileName in stringfileName)
                {
                    FileInfo fileinfo = new FileInfo(fileName);
                    Icon icon = Icon.ExtractAssociatedIcon(fileName);
                    listViewControl.LargeImageList.Images.Add(fileinfo.Extension, icon);
                    if ((fileinfo.Attributes & FileAttributes.Hidden) == 0 && (fileinfo.Attributes & FileAttributes.Temporary) == 0)
                    {
                        String[] lvfile = new String[4];
                        String[] nfile = fileinfo.FullName.Split('\\');
                        lvfile[0] = nfile[nfile.Length - 1];
                        lvfile[1] = fileinfo.CreationTime.ToShortDateString();
                        lvfile[2] = fileinfo.LastWriteTime.ToShortDateString();

                        double sf;
                        if ((fileinfo.Length > 0) && (fileinfo.Length < 1024))
                        {
                            sf = fileinfo.Length;
                            lvfile[3] = sf.ToString() + " B";
                        }
                        if ((fileinfo.Length >= 1024) && (fileinfo.Length < 1048576))
                        {
                            sf = fileinfo.Length / 1024;
                            lvfile[3] = sf.ToString() + " KB";
                        }
                        if ((fileinfo.Length >= 1048576) && (fileinfo.Length < 1073741824))
                        {
                            sf = fileinfo.Length / 1048576;
                            lvfile[3] = sf.ToString() + " MB";
                        }
                        if (fileinfo.Length >= 1073741824)
                        {
                            sf = fileinfo.Length / 1073741824;
                            lvfile[3] = sf.ToString() + " GB";
                        }
                        ListViewItem itemfile = new ListViewItem(lvfile);
                        if (itemfile.Text[0] == '\\')
                            itemfile.Text = itemfile.Text.Substring(1);
                        itemfile.ImageIndex = listViewControl.LargeImageList.Images.Count - 1;
                        itemfile.Tag = fileName;
                        itemfile.Name = itemfile.Tag.ToString();
                        listViewControl.Items.Add(itemfile);
                    }
                }
                listViewControl.Columns.Add("Name", 200);
                listViewControl.Columns.Add("Date", 150);
                listViewControl.Columns.Add("Modified Date", 150);
                listViewControl.Columns.Add("Size", 100);
            }
            catch (Exception)
            {
                listViewControl.Items.Clear();
                listViewControl.Columns.Clear();
                listViewControl.Columns.Add("Name", 200);
                listViewControl.Columns.Add("Type", 100);
                listViewControl.Columns.Add("Total Size", 100);
                listViewControl.Columns.Add("Free Space", 100);
                String[] stringfileName = Directory.GetLogicalDrives();
                foreach (string fileName in stringfileName)
                {
                    DriveInfo fileinfo = new DriveInfo(fileName);
                    String[] lvfile = new String[4];
                    lvfile[0] = fileinfo.Name.ToString();
                    lvfile[1] = fileinfo.DriveType.ToString();
                    if (fileinfo.IsReady == true)
                    {
                        if (fileinfo.TotalSize > 1073741824)
                        {
                            double s = fileinfo.TotalSize / 1073741824;
                            lvfile[2] = s.ToString() + " GB";
                        }
                        double sf;
                        if ((fileinfo.TotalFreeSpace > 0) && (fileinfo.TotalFreeSpace < 1024))
                        {
                            sf = fileinfo.TotalFreeSpace;
                            lvfile[3] = sf.ToString() + " B";
                        }
                        if ((fileinfo.TotalFreeSpace >= 1024) && (fileinfo.TotalFreeSpace < 1048576))
                        {
                            sf = fileinfo.TotalFreeSpace / 1024;
                            lvfile[3] = sf.ToString() + " KB";
                        }
                        if ((fileinfo.TotalFreeSpace >= 1048576) && (fileinfo.TotalFreeSpace < 1073741824))
                        {
                            sf = fileinfo.TotalFreeSpace / 1048576;
                            lvfile[3] = sf.ToString() + " MB";
                        }
                        if (fileinfo.TotalFreeSpace >= 1073741824)
                        {
                            sf = fileinfo.TotalFreeSpace / 1073741824;
                            lvfile[3] = sf.ToString() + " GB";
                        }
                    }
                    ListViewItem itemfile = new ListViewItem(lvfile);
                    listViewControl.Items.Add(itemfile);
                    itemfile.ImageIndex = 2;
                }
            }
            listViewControl.View = View.Details;
        }

    }
}
