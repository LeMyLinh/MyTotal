﻿namespace TotalCommander
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.RibConMenu = new DevComponents.DotNetBar.RibbonControl();
            this.ribbonPanel4 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar4 = new DevComponents.DotNetBar.RibbonBar();
            this.btnInfor = new DevComponents.DotNetBar.ButtonItem();
            this.btnHelp = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel3 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar5 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer8 = new DevComponents.DotNetBar.ItemContainer();
            this.btnCmd = new DevComponents.DotNetBar.ButtonItem();
            this.btnTaskManage = new DevComponents.DotNetBar.ButtonItem();
            this.btnNotepad = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel1 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar1 = new DevComponents.DotNetBar.RibbonBar();
            this.btnFind = new DevComponents.DotNetBar.ButtonItem();
            this.ribOrganize = new DevComponents.DotNetBar.RibbonBar();
            this.btnNew = new DevComponents.DotNetBar.ButtonItem();
            this.btnNewFolder = new DevComponents.DotNetBar.ButtonItem();
            this.btnNewText = new DevComponents.DotNetBar.ButtonItem();
            this.btnNewWord = new DevComponents.DotNetBar.ButtonItem();
            this.btnNewExcel = new DevComponents.DotNetBar.ButtonItem();
            this.btnRename = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer5 = new DevComponents.DotNetBar.ItemContainer();
            this.btnCopy = new DevComponents.DotNetBar.ButtonItem();
            this.btnCut = new DevComponents.DotNetBar.ButtonItem();
            this.btnPaste = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer6 = new DevComponents.DotNetBar.ItemContainer();
            this.btnCopyToFolder = new DevComponents.DotNetBar.ButtonItem();
            this.btnMoveToFolder = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer7 = new DevComponents.DotNetBar.ItemContainer();
            this.btnDelete = new DevComponents.DotNetBar.ButtonItem();
            this.btnRecycle = new DevComponents.DotNetBar.ButtonItem();
            this.btnPerDel = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel2 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar3 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer3 = new DevComponents.DotNetBar.ItemContainer();
            this.btnLargeIcon = new DevComponents.DotNetBar.ButtonItem();
            this.btnSmallIcon = new DevComponents.DotNetBar.ButtonItem();
            this.btnListLayout = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar2 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer2 = new DevComponents.DotNetBar.ItemContainer();
            this.btnTreeView = new DevComponents.DotNetBar.ButtonItem();
            this.btnListView = new DevComponents.DotNetBar.ButtonItem();
            this.tabTools = new DevComponents.DotNetBar.RibbonTabItem();
            this.tabView = new DevComponents.DotNetBar.RibbonTabItem();
            this.tabApp = new DevComponents.DotNetBar.RibbonTabItem();
            this.tabHelp = new DevComponents.DotNetBar.RibbonTabItem();
            this.applicationButton1 = new DevComponents.DotNetBar.ApplicationButton();
            this.itemContainer1 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer4 = new DevComponents.DotNetBar.ItemContainer();
            this.buttonItem13 = new DevComponents.DotNetBar.ButtonItem();
            this.StyleManage = new DevComponents.DotNetBar.StyleManager(this.components);
            this.SplitContainer = new System.Windows.Forms.SplitContainer();
            this.Panel1_ListViewLeft = new System.Windows.Forms.ListView();
            this.colName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSize = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDateCreated = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDateModified = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.spc1_pan1_statusStrip = new System.Windows.Forms.StatusStrip();
            this.Panel1_StatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.Panel1_LabelLeft = new System.Windows.Forms.Label();
            this.Panel1_ComboLeft = new System.Windows.Forms.ComboBox();
            this.Panel1_TreeViewLeft = new System.Windows.Forms.TreeView();
            this.Panel2_ListViewRight = new System.Windows.Forms.ListView();
            this.colNameRight = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSizeRight = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDateCreatedRight = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDateModifiedRight = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.spc1_pan2_statusStrip = new System.Windows.Forms.StatusStrip();
            this.spc1_pan2_statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.Panel2_StatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.process_shutdown = new System.Windows.Forms.ToolStripProgressBar();
            this.Panel2_LabelRight = new System.Windows.Forms.Label();
            this.Panel2_ComboRight = new System.Windows.Forms.ComboBox();
            this.Panel2_TreeViewRight = new System.Windows.Forms.TreeView();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.lbn_process = new System.Windows.Forms.ToolStripStatusLabel();
            this.processBar = new System.Windows.Forms.ToolStripProgressBar();
            this.fbdFolderDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.TreeImageList = new System.Windows.Forms.ImageList(this.components);
            this.LargeImageList = new System.Windows.Forms.ImageList(this.components);
            this.SmallImageList = new System.Windows.Forms.ImageList(this.components);
            this.RibConMenu.SuspendLayout();
            this.ribbonPanel4.SuspendLayout();
            this.ribbonPanel3.SuspendLayout();
            this.ribbonPanel1.SuspendLayout();
            this.ribbonPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SplitContainer)).BeginInit();
            this.SplitContainer.Panel1.SuspendLayout();
            this.SplitContainer.Panel2.SuspendLayout();
            this.SplitContainer.SuspendLayout();
            this.spc1_pan1_statusStrip.SuspendLayout();
            this.spc1_pan2_statusStrip.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // RibConMenu
            // 
            // 
            // 
            // 
            this.RibConMenu.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.RibConMenu.CaptionVisible = true;
            this.RibConMenu.Controls.Add(this.ribbonPanel1);
            this.RibConMenu.Controls.Add(this.ribbonPanel2);
            this.RibConMenu.Controls.Add(this.ribbonPanel3);
            this.RibConMenu.Controls.Add(this.ribbonPanel4);
            this.RibConMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.RibConMenu.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.tabTools,
            this.tabView,
            this.tabApp,
            this.tabHelp});
            this.RibConMenu.KeyTipsFont = new System.Drawing.Font("Tahoma", 7F);
            this.RibConMenu.Location = new System.Drawing.Point(5, 1);
            this.RibConMenu.Name = "RibConMenu";
            this.RibConMenu.Padding = new System.Windows.Forms.Padding(0, 0, 0, 3);
            this.RibConMenu.QuickToolbarItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.applicationButton1});
            this.RibConMenu.Size = new System.Drawing.Size(990, 155);
            this.RibConMenu.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.RibConMenu.SystemText.MaximizeRibbonText = "&Maximize the Ribbon";
            this.RibConMenu.SystemText.MinimizeRibbonText = "Mi&nimize the Ribbon";
            this.RibConMenu.SystemText.QatAddItemText = "&Add to Quick Access Toolbar";
            this.RibConMenu.SystemText.QatCustomizeMenuLabel = "<b>Customize Quick Access Toolbar</b>";
            this.RibConMenu.SystemText.QatCustomizeText = "&Customize Quick Access Toolbar...";
            this.RibConMenu.SystemText.QatDialogAddButton = "&Add >>";
            this.RibConMenu.SystemText.QatDialogCancelButton = "Cancel";
            this.RibConMenu.SystemText.QatDialogCaption = "Customize Quick Access Toolbar";
            this.RibConMenu.SystemText.QatDialogCategoriesLabel = "&Choose commands from:";
            this.RibConMenu.SystemText.QatDialogOkButton = "OK";
            this.RibConMenu.SystemText.QatDialogPlacementCheckbox = "&Place Quick Access Toolbar below the Ribbon";
            this.RibConMenu.SystemText.QatDialogRemoveButton = "&Remove";
            this.RibConMenu.SystemText.QatPlaceAboveRibbonText = "&Place Quick Access Toolbar above the Ribbon";
            this.RibConMenu.SystemText.QatPlaceBelowRibbonText = "&Place Quick Access Toolbar below the Ribbon";
            this.RibConMenu.SystemText.QatRemoveItemText = "&Remove from Quick Access Toolbar";
            this.RibConMenu.TabGroupHeight = 14;
            this.RibConMenu.TabIndex = 0;
            this.RibConMenu.Text = "ribbonControl1";
            // 
            // ribbonPanel4
            // 
            this.ribbonPanel4.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel4.Controls.Add(this.ribbonBar4);
            this.ribbonPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel4.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel4.Name = "ribbonPanel4";
            this.ribbonPanel4.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel4.Size = new System.Drawing.Size(990, 96);
            // 
            // 
            // 
            this.ribbonPanel4.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel4.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel4.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel4.TabIndex = 4;
            this.ribbonPanel4.Visible = false;
            // 
            // ribbonBar4
            // 
            this.ribbonBar4.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar4.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar4.ContainerControlProcessDialogKey = true;
            this.ribbonBar4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonBar4.DragDropSupport = true;
            this.ribbonBar4.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnInfor,
            this.btnHelp});
            this.ribbonBar4.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar4.Name = "ribbonBar4";
            this.ribbonBar4.Size = new System.Drawing.Size(984, 93);
            this.ribbonBar4.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar4.TabIndex = 0;
            // 
            // 
            // 
            this.ribbonBar4.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar4.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnInfor
            // 
            this.btnInfor.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnInfor.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnInfor.Image = ((System.Drawing.Image)(resources.GetObject("btnInfor.Image")));
            this.btnInfor.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnInfor.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnInfor.Name = "btnInfor";
            this.btnInfor.Text = "Information";
            this.btnInfor.Click += new System.EventHandler(this.btnInfor_Click);
            // 
            // btnHelp
            // 
            this.btnHelp.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnHelp.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnHelp.Image = ((System.Drawing.Image)(resources.GetObject("btnHelp.Image")));
            this.btnHelp.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnHelp.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Text = "Help";
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // ribbonPanel3
            // 
            this.ribbonPanel3.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel3.Controls.Add(this.ribbonBar5);
            this.ribbonPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel3.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel3.Name = "ribbonPanel3";
            this.ribbonPanel3.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel3.Size = new System.Drawing.Size(990, 96);
            // 
            // 
            // 
            this.ribbonPanel3.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel3.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel3.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel3.TabIndex = 3;
            this.ribbonPanel3.Visible = false;
            // 
            // ribbonBar5
            // 
            this.ribbonBar5.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar5.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar5.ContainerControlProcessDialogKey = true;
            this.ribbonBar5.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar5.DragDropSupport = true;
            this.ribbonBar5.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer8});
            this.ribbonBar5.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar5.Name = "ribbonBar5";
            this.ribbonBar5.Size = new System.Drawing.Size(167, 93);
            this.ribbonBar5.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar5.TabIndex = 0;
            this.ribbonBar5.Text = "System";
            // 
            // 
            // 
            this.ribbonBar5.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar5.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer8
            // 
            // 
            // 
            // 
            this.itemContainer8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer8.Name = "itemContainer8";
            this.itemContainer8.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnCmd,
            this.btnTaskManage,
            this.btnNotepad});
            // 
            // 
            // 
            this.itemContainer8.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnCmd
            // 
            this.btnCmd.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnCmd.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnCmd.Image = global::TotalCommander.Properties.Resources.cmd;
            this.btnCmd.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnCmd.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnCmd.Name = "btnCmd";
            this.btnCmd.Text = "Cmd";
            this.btnCmd.Click += new System.EventHandler(this.btnCmd_Click);
            // 
            // btnTaskManage
            // 
            this.btnTaskManage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnTaskManage.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnTaskManage.Image = global::TotalCommander.Properties.Resources.taskmanage;
            this.btnTaskManage.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnTaskManage.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnTaskManage.Name = "btnTaskManage";
            this.btnTaskManage.Text = "Task Manage";
            this.btnTaskManage.Click += new System.EventHandler(this.btnTaskManage_Click);
            // 
            // btnNotepad
            // 
            this.btnNotepad.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnNotepad.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnNotepad.Image = global::TotalCommander.Properties.Resources.notepad_icon_jpg;
            this.btnNotepad.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnNotepad.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnNotepad.Name = "btnNotepad";
            this.btnNotepad.Text = "Notepad";
            this.btnNotepad.Click += new System.EventHandler(this.btnNotepad_Click);
            // 
            // ribbonPanel1
            // 
            this.ribbonPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel1.Controls.Add(this.ribbonBar1);
            this.ribbonPanel1.Controls.Add(this.ribOrganize);
            this.ribbonPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel1.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel1.Name = "ribbonPanel1";
            this.ribbonPanel1.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel1.Size = new System.Drawing.Size(990, 96);
            // 
            // 
            // 
            this.ribbonPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel1.TabIndex = 1;
            // 
            // ribbonBar1
            // 
            this.ribbonBar1.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar1.ContainerControlProcessDialogKey = true;
            this.ribbonBar1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonBar1.DragDropSupport = true;
            this.ribbonBar1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnFind});
            this.ribbonBar1.Location = new System.Drawing.Point(411, 0);
            this.ribbonBar1.Name = "ribbonBar1";
            this.ribbonBar1.Size = new System.Drawing.Size(576, 93);
            this.ribbonBar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar1.TabIndex = 1;
            // 
            // 
            // 
            this.ribbonBar1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnFind
            // 
            this.btnFind.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnFind.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnFind.Image = ((System.Drawing.Image)(resources.GetObject("btnFind.Image")));
            this.btnFind.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnFind.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnFind.Name = "btnFind";
            this.btnFind.Text = "Find";
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // ribOrganize
            // 
            this.ribOrganize.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribOrganize.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribOrganize.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribOrganize.ContainerControlProcessDialogKey = true;
            this.ribOrganize.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribOrganize.DragDropSupport = true;
            this.ribOrganize.ForeColor = System.Drawing.Color.White;
            this.ribOrganize.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnNew,
            this.btnRename,
            this.itemContainer5,
            this.itemContainer6,
            this.itemContainer7});
            this.ribOrganize.Location = new System.Drawing.Point(3, 0);
            this.ribOrganize.Name = "ribOrganize";
            this.ribOrganize.Size = new System.Drawing.Size(408, 93);
            this.ribOrganize.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribOrganize.TabIndex = 0;
            this.ribOrganize.Text = "Organize";
            // 
            // 
            // 
            this.ribOrganize.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribOrganize.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnNew
            // 
            this.btnNew.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnNew.ForeColor = System.Drawing.Color.Navy;
            this.btnNew.Image = ((System.Drawing.Image)(resources.GetObject("btnNew.Image")));
            this.btnNew.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnNew.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnNew.Name = "btnNew";
            this.btnNew.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnNewFolder,
            this.btnNewText,
            this.btnNewWord,
            this.btnNewExcel});
            this.btnNew.SubItemsExpandWidth = 14;
            this.btnNew.Text = "New";
            // 
            // btnNewFolder
            // 
            this.btnNewFolder.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnNewFolder.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnNewFolder.Image = ((System.Drawing.Image)(resources.GetObject("btnNewFolder.Image")));
            this.btnNewFolder.ImageFixedSize = new System.Drawing.Size(30, 30);
            this.btnNewFolder.Name = "btnNewFolder";
            this.btnNewFolder.Text = "New Folder";
            this.btnNewFolder.Click += new System.EventHandler(this.btnNewFolder_Click);
            // 
            // btnNewText
            // 
            this.btnNewText.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnNewText.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnNewText.Image = ((System.Drawing.Image)(resources.GetObject("btnNewText.Image")));
            this.btnNewText.ImageFixedSize = new System.Drawing.Size(30, 30);
            this.btnNewText.Name = "btnNewText";
            this.btnNewText.Text = "New File Text";
            this.btnNewText.Click += new System.EventHandler(this.btnNewText_Click);
            // 
            // btnNewWord
            // 
            this.btnNewWord.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnNewWord.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnNewWord.Image = ((System.Drawing.Image)(resources.GetObject("btnNewWord.Image")));
            this.btnNewWord.ImageFixedSize = new System.Drawing.Size(30, 30);
            this.btnNewWord.Name = "btnNewWord";
            this.btnNewWord.Text = "New File Word";
            this.btnNewWord.Click += new System.EventHandler(this.btnNewWord_Click);
            // 
            // btnNewExcel
            // 
            this.btnNewExcel.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnNewExcel.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnNewExcel.Image = ((System.Drawing.Image)(resources.GetObject("btnNewExcel.Image")));
            this.btnNewExcel.ImageFixedSize = new System.Drawing.Size(30, 30);
            this.btnNewExcel.Name = "btnNewExcel";
            this.btnNewExcel.Text = "New File Excel";
            this.btnNewExcel.Click += new System.EventHandler(this.btnNewExcel_Click);
            // 
            // btnRename
            // 
            this.btnRename.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnRename.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnRename.Image = ((System.Drawing.Image)(resources.GetObject("btnRename.Image")));
            this.btnRename.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnRename.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnRename.Name = "btnRename";
            this.btnRename.Text = "Rename";
            this.btnRename.Click += new System.EventHandler(this.btnRename_Click);
            // 
            // itemContainer5
            // 
            // 
            // 
            // 
            this.itemContainer5.BackgroundStyle.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.itemContainer5.BackgroundStyle.BorderLeftColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.MenuBarBackground2;
            this.itemContainer5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer5.Name = "itemContainer5";
            this.itemContainer5.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnCopy,
            this.btnCut,
            this.btnPaste});
            // 
            // 
            // 
            this.itemContainer5.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnCopy
            // 
            this.btnCopy.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnCopy.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnCopy.Image = ((System.Drawing.Image)(resources.GetObject("btnCopy.Image")));
            this.btnCopy.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnCopy.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Text = "Copy";
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // btnCut
            // 
            this.btnCut.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnCut.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnCut.Image = ((System.Drawing.Image)(resources.GetObject("btnCut.Image")));
            this.btnCut.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnCut.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnCut.Name = "btnCut";
            this.btnCut.Text = "Cut";
            this.btnCut.Click += new System.EventHandler(this.btnCut_Click);
            // 
            // btnPaste
            // 
            this.btnPaste.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnPaste.ForeColor = System.Drawing.Color.Navy;
            this.btnPaste.Image = ((System.Drawing.Image)(resources.GetObject("btnPaste.Image")));
            this.btnPaste.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnPaste.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnPaste.Name = "btnPaste";
            this.btnPaste.SubItemsExpandWidth = 14;
            this.btnPaste.Text = "&Paste";
            this.btnPaste.Click += new System.EventHandler(this.btnPaste_Click);
            // 
            // itemContainer6
            // 
            // 
            // 
            // 
            this.itemContainer6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer6.Name = "itemContainer6";
            this.itemContainer6.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnCopyToFolder,
            this.btnMoveToFolder});
            // 
            // 
            // 
            this.itemContainer6.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnCopyToFolder
            // 
            this.btnCopyToFolder.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnCopyToFolder.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnCopyToFolder.Image = ((System.Drawing.Image)(resources.GetObject("btnCopyToFolder.Image")));
            this.btnCopyToFolder.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnCopyToFolder.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnCopyToFolder.Name = "btnCopyToFolder";
            this.btnCopyToFolder.Text = "Copy To Folder";
            this.btnCopyToFolder.Click += new System.EventHandler(this.btnCopyToFolder_Click);
            // 
            // btnMoveToFolder
            // 
            this.btnMoveToFolder.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnMoveToFolder.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnMoveToFolder.Image = ((System.Drawing.Image)(resources.GetObject("btnMoveToFolder.Image")));
            this.btnMoveToFolder.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnMoveToFolder.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnMoveToFolder.Name = "btnMoveToFolder";
            this.btnMoveToFolder.Text = "Move To Folder";
            this.btnMoveToFolder.Click += new System.EventHandler(this.btnMoveToFolder_Click);
            // 
            // itemContainer7
            // 
            // 
            // 
            // 
            this.itemContainer7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer7.Name = "itemContainer7";
            this.itemContainer7.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnDelete});
            // 
            // 
            // 
            this.itemContainer7.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnDelete
            // 
            this.btnDelete.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDelete.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnDelete.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnRecycle,
            this.btnPerDel});
            this.btnDelete.Text = "Delete";
            // 
            // btnRecycle
            // 
            this.btnRecycle.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnRecycle.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnRecycle.Image = ((System.Drawing.Image)(resources.GetObject("btnRecycle.Image")));
            this.btnRecycle.ImageFixedSize = new System.Drawing.Size(30, 30);
            this.btnRecycle.Name = "btnRecycle";
            this.btnRecycle.Text = "Recycle";
            this.btnRecycle.Click += new System.EventHandler(this.btnRecycle_Click);
            // 
            // btnPerDel
            // 
            this.btnPerDel.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnPerDel.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnPerDel.Image = ((System.Drawing.Image)(resources.GetObject("btnPerDel.Image")));
            this.btnPerDel.ImageFixedSize = new System.Drawing.Size(30, 30);
            this.btnPerDel.Name = "btnPerDel";
            this.btnPerDel.Text = "Permanently Delete";
            this.btnPerDel.Click += new System.EventHandler(this.btnPerDel_Click);
            // 
            // ribbonPanel2
            // 
            this.ribbonPanel2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel2.Controls.Add(this.ribbonBar3);
            this.ribbonPanel2.Controls.Add(this.ribbonBar2);
            this.ribbonPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel2.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel2.Name = "ribbonPanel2";
            this.ribbonPanel2.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel2.Size = new System.Drawing.Size(990, 96);
            // 
            // 
            // 
            this.ribbonPanel2.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel2.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel2.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel2.TabIndex = 2;
            this.ribbonPanel2.Visible = false;
            // 
            // ribbonBar3
            // 
            this.ribbonBar3.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar3.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar3.ContainerControlProcessDialogKey = true;
            this.ribbonBar3.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar3.DragDropSupport = true;
            this.ribbonBar3.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer3});
            this.ribbonBar3.Location = new System.Drawing.Point(133, 0);
            this.ribbonBar3.Name = "ribbonBar3";
            this.ribbonBar3.Size = new System.Drawing.Size(155, 93);
            this.ribbonBar3.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar3.TabIndex = 1;
            this.ribbonBar3.Text = "Layout";
            // 
            // 
            // 
            this.ribbonBar3.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar3.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer3
            // 
            // 
            // 
            // 
            this.itemContainer3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer3.Name = "itemContainer3";
            this.itemContainer3.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnLargeIcon,
            this.btnSmallIcon,
            this.btnListLayout});
            // 
            // 
            // 
            this.itemContainer3.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnLargeIcon
            // 
            this.btnLargeIcon.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnLargeIcon.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnLargeIcon.Image = ((System.Drawing.Image)(resources.GetObject("btnLargeIcon.Image")));
            this.btnLargeIcon.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnLargeIcon.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnLargeIcon.Name = "btnLargeIcon";
            this.btnLargeIcon.Text = "Large Icon";
            this.btnLargeIcon.Click += new System.EventHandler(this.btnLargeIcon_Click);
            // 
            // btnSmallIcon
            // 
            this.btnSmallIcon.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnSmallIcon.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnSmallIcon.Image = ((System.Drawing.Image)(resources.GetObject("btnSmallIcon.Image")));
            this.btnSmallIcon.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnSmallIcon.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnSmallIcon.Name = "btnSmallIcon";
            this.btnSmallIcon.Text = "Small Icon";
            this.btnSmallIcon.Click += new System.EventHandler(this.btnSmallIcon_Click);
            // 
            // btnListLayout
            // 
            this.btnListLayout.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnListLayout.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnListLayout.Image = ((System.Drawing.Image)(resources.GetObject("btnListLayout.Image")));
            this.btnListLayout.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnListLayout.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnListLayout.Name = "btnListLayout";
            this.btnListLayout.Text = "List";
            this.btnListLayout.Click += new System.EventHandler(this.btnListLayout_Click);
            // 
            // ribbonBar2
            // 
            this.ribbonBar2.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar2.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar2.ContainerControlProcessDialogKey = true;
            this.ribbonBar2.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar2.DragDropSupport = true;
            this.ribbonBar2.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer2});
            this.ribbonBar2.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar2.Name = "ribbonBar2";
            this.ribbonBar2.Size = new System.Drawing.Size(130, 93);
            this.ribbonBar2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar2.TabIndex = 0;
            this.ribbonBar2.Text = "Panes";
            // 
            // 
            // 
            this.ribbonBar2.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar2.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer2
            // 
            // 
            // 
            // 
            this.itemContainer2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer2.Name = "itemContainer2";
            this.itemContainer2.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnTreeView,
            this.btnListView});
            // 
            // 
            // 
            this.itemContainer2.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // btnTreeView
            // 
            this.btnTreeView.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnTreeView.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnTreeView.Image = ((System.Drawing.Image)(resources.GetObject("btnTreeView.Image")));
            this.btnTreeView.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnTreeView.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnTreeView.Name = "btnTreeView";
            this.btnTreeView.Text = "Tree View";
            this.btnTreeView.Click += new System.EventHandler(this.btnTreeView_Click);
            // 
            // btnListView
            // 
            this.btnListView.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnListView.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.btnListView.Image = ((System.Drawing.Image)(resources.GetObject("btnListView.Image")));
            this.btnListView.ImageFixedSize = new System.Drawing.Size(40, 40);
            this.btnListView.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnListView.Name = "btnListView";
            this.btnListView.Text = "List View";
            this.btnListView.Click += new System.EventHandler(this.btnListView_Click);
            // 
            // tabTools
            // 
            this.tabTools.Checked = true;
            this.tabTools.Name = "tabTools";
            this.tabTools.Panel = this.ribbonPanel1;
            this.tabTools.Text = "Tools";
            // 
            // tabView
            // 
            this.tabView.Name = "tabView";
            this.tabView.Panel = this.ribbonPanel2;
            this.tabView.Text = "View";
            // 
            // tabApp
            // 
            this.tabApp.Name = "tabApp";
            this.tabApp.Panel = this.ribbonPanel3;
            this.tabApp.Text = "Applications";
            // 
            // tabHelp
            // 
            this.tabHelp.Name = "tabHelp";
            this.tabHelp.Panel = this.ribbonPanel4;
            this.tabHelp.Text = "Help";
            // 
            // applicationButton1
            // 
            this.applicationButton1.AutoExpandOnClick = true;
            this.applicationButton1.CanCustomize = false;
            this.applicationButton1.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image;
            this.applicationButton1.Image = ((System.Drawing.Image)(resources.GetObject("applicationButton1.Image")));
            this.applicationButton1.ImageFixedSize = new System.Drawing.Size(30, 30);
            this.applicationButton1.ImageListSizeSelection = DevComponents.DotNetBar.eButtonImageListSelection.Medium;
            this.applicationButton1.ImagePaddingHorizontal = 2;
            this.applicationButton1.ImagePaddingVertical = 2;
            this.applicationButton1.Name = "applicationButton1";
            this.applicationButton1.ShowSubItems = false;
            this.applicationButton1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer1});
            this.applicationButton1.Text = "&File";
            // 
            // itemContainer1
            // 
            // 
            // 
            // 
            this.itemContainer1.BackgroundStyle.Class = "RibbonFileMenuContainer";
            this.itemContainer1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer1.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer1.Name = "itemContainer1";
            this.itemContainer1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer4});
            // 
            // 
            // 
            this.itemContainer1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer4
            // 
            // 
            // 
            // 
            this.itemContainer4.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer4.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer4.Name = "itemContainer4";
            this.itemContainer4.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem13});
            // 
            // 
            // 
            this.itemContainer4.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // buttonItem13
            // 
            this.buttonItem13.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem13.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonItem13.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem13.Image")));
            this.buttonItem13.Name = "buttonItem13";
            this.buttonItem13.SubItemsExpandWidth = 24;
            this.buttonItem13.Text = "E&xit";
            this.buttonItem13.Click += new System.EventHandler(this.buttonItem13_Click);
            // 
            // StyleManage
            // 
            this.StyleManage.ManagerStyle = DevComponents.DotNetBar.eStyle.Office2007VistaGlass;
            this.StyleManage.MetroColorParameters = new DevComponents.DotNetBar.Metro.ColorTables.MetroColorGeneratorParameters(System.Drawing.Color.White, System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(87)))), ((int)(((byte)(154))))));
            // 
            // SplitContainer
            // 
            this.SplitContainer.AllowDrop = true;
            this.SplitContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SplitContainer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SplitContainer.Location = new System.Drawing.Point(8, 156);
            this.SplitContainer.Name = "SplitContainer";
            // 
            // SplitContainer.Panel1
            // 
            this.SplitContainer.Panel1.AllowDrop = true;
            this.SplitContainer.Panel1.Controls.Add(this.Panel1_ListViewLeft);
            this.SplitContainer.Panel1.Controls.Add(this.spc1_pan1_statusStrip);
            this.SplitContainer.Panel1.Controls.Add(this.Panel1_LabelLeft);
            this.SplitContainer.Panel1.Controls.Add(this.Panel1_ComboLeft);
            this.SplitContainer.Panel1.Controls.Add(this.Panel1_TreeViewLeft);
            this.SplitContainer.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // SplitContainer.Panel2
            // 
            this.SplitContainer.Panel2.AllowDrop = true;
            this.SplitContainer.Panel2.Controls.Add(this.Panel2_ListViewRight);
            this.SplitContainer.Panel2.Controls.Add(this.spc1_pan2_statusStrip);
            this.SplitContainer.Panel2.Controls.Add(this.Panel2_LabelRight);
            this.SplitContainer.Panel2.Controls.Add(this.Panel2_ComboRight);
            this.SplitContainer.Panel2.Controls.Add(this.Panel2_TreeViewRight);
            this.SplitContainer.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SplitContainer.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SplitContainer.Size = new System.Drawing.Size(987, 465);
            this.SplitContainer.SplitterDistance = 494;
            this.SplitContainer.SplitterWidth = 5;
            this.SplitContainer.TabIndex = 3;
            // 
            // Panel1_ListViewLeft
            // 
            this.Panel1_ListViewLeft.AllowDrop = true;
            this.Panel1_ListViewLeft.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel1_ListViewLeft.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colName,
            this.colSize,
            this.colDateCreated,
            this.colDateModified});
            this.Panel1_ListViewLeft.LabelEdit = true;
            this.Panel1_ListViewLeft.Location = new System.Drawing.Point(6, 30);
            this.Panel1_ListViewLeft.Name = "Panel1_ListViewLeft";
            this.Panel1_ListViewLeft.Size = new System.Drawing.Size(480, 406);
            this.Panel1_ListViewLeft.TabIndex = 1;
            this.Panel1_ListViewLeft.UseCompatibleStateImageBehavior = false;
            this.Panel1_ListViewLeft.View = System.Windows.Forms.View.Details;
            this.Panel1_ListViewLeft.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Panel1_ListViewLeft_KeyDown);
            // 
            // colName
            // 
            this.colName.Text = "Name";
            this.colName.Width = 200;
            // 
            // colSize
            // 
            this.colSize.Text = "Size";
            this.colSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colSize.Width = 80;
            // 
            // colDateCreated
            // 
            this.colDateCreated.Text = "Date Created";
            this.colDateCreated.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colDateCreated.Width = 100;
            // 
            // colDateModified
            // 
            this.colDateModified.Text = "Date Modified";
            this.colDateModified.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colDateModified.Width = 100;
            // 
            // spc1_pan1_statusStrip
            // 
            this.spc1_pan1_statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Panel1_StatusLabel});
            this.spc1_pan1_statusStrip.Location = new System.Drawing.Point(0, 439);
            this.spc1_pan1_statusStrip.Name = "spc1_pan1_statusStrip";
            this.spc1_pan1_statusStrip.Size = new System.Drawing.Size(490, 22);
            this.spc1_pan1_statusStrip.TabIndex = 3;
            this.spc1_pan1_statusStrip.Text = "statusStrip2";
            // 
            // Panel1_StatusLabel
            // 
            this.Panel1_StatusLabel.Name = "Panel1_StatusLabel";
            this.Panel1_StatusLabel.Size = new System.Drawing.Size(16, 17);
            this.Panel1_StatusLabel.Text = "...";
            // 
            // Panel1_LabelLeft
            // 
            this.Panel1_LabelLeft.AutoSize = true;
            this.Panel1_LabelLeft.Location = new System.Drawing.Point(140, 6);
            this.Panel1_LabelLeft.Name = "Panel1_LabelLeft";
            this.Panel1_LabelLeft.Size = new System.Drawing.Size(16, 13);
            this.Panel1_LabelLeft.TabIndex = 3;
            this.Panel1_LabelLeft.Text = "...";
            // 
            // Panel1_ComboLeft
            // 
            this.Panel1_ComboLeft.FormattingEnabled = true;
            this.Panel1_ComboLeft.Location = new System.Drawing.Point(6, 3);
            this.Panel1_ComboLeft.Name = "Panel1_ComboLeft";
            this.Panel1_ComboLeft.Size = new System.Drawing.Size(122, 21);
            this.Panel1_ComboLeft.TabIndex = 2;
            // 
            // Panel1_TreeViewLeft
            // 
            this.Panel1_TreeViewLeft.AllowDrop = true;
            this.Panel1_TreeViewLeft.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel1_TreeViewLeft.Location = new System.Drawing.Point(6, 30);
            this.Panel1_TreeViewLeft.Name = "Panel1_TreeViewLeft";
            this.Panel1_TreeViewLeft.Size = new System.Drawing.Size(481, 406);
            this.Panel1_TreeViewLeft.TabIndex = 0;
            // 
            // Panel2_ListViewRight
            // 
            this.Panel2_ListViewRight.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel2_ListViewRight.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colNameRight,
            this.colSizeRight,
            this.colDateCreatedRight,
            this.colDateModifiedRight});
            this.Panel2_ListViewRight.Location = new System.Drawing.Point(4, 30);
            this.Panel2_ListViewRight.Name = "Panel2_ListViewRight";
            this.Panel2_ListViewRight.Size = new System.Drawing.Size(471, 406);
            this.Panel2_ListViewRight.TabIndex = 5;
            this.Panel2_ListViewRight.UseCompatibleStateImageBehavior = false;
            this.Panel2_ListViewRight.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Panel2_ListViewRight_KeyDown);
            // 
            // colNameRight
            // 
            this.colNameRight.Text = "Name";
            this.colNameRight.Width = 200;
            // 
            // colSizeRight
            // 
            this.colSizeRight.Text = "Size";
            this.colSizeRight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colSizeRight.Width = 80;
            // 
            // colDateCreatedRight
            // 
            this.colDateCreatedRight.Text = "Date Created";
            this.colDateCreatedRight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colDateCreatedRight.Width = 100;
            // 
            // colDateModifiedRight
            // 
            this.colDateModifiedRight.Text = "Date Modified";
            this.colDateModifiedRight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colDateModifiedRight.Width = 100;
            // 
            // spc1_pan2_statusStrip
            // 
            this.spc1_pan2_statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.spc1_pan2_statusLabel,
            this.Panel2_StatusLabel,
            this.process_shutdown});
            this.spc1_pan2_statusStrip.Location = new System.Drawing.Point(0, 439);
            this.spc1_pan2_statusStrip.Name = "spc1_pan2_statusStrip";
            this.spc1_pan2_statusStrip.Size = new System.Drawing.Size(484, 22);
            this.spc1_pan2_statusStrip.TabIndex = 3;
            this.spc1_pan2_statusStrip.Text = "statusStrip3";
            // 
            // spc1_pan2_statusLabel
            // 
            this.spc1_pan2_statusLabel.Name = "spc1_pan2_statusLabel";
            this.spc1_pan2_statusLabel.Size = new System.Drawing.Size(16, 17);
            this.spc1_pan2_statusLabel.Text = "...";
            // 
            // Panel2_StatusLabel
            // 
            this.Panel2_StatusLabel.BackColor = System.Drawing.Color.LightSteelBlue;
            this.Panel2_StatusLabel.Name = "Panel2_StatusLabel";
            this.Panel2_StatusLabel.Size = new System.Drawing.Size(95, 17);
            this.Panel2_StatusLabel.Text = "Thời gian còn lại";
            // 
            // process_shutdown
            // 
            this.process_shutdown.BackColor = System.Drawing.Color.LightSteelBlue;
            this.process_shutdown.Name = "process_shutdown";
            this.process_shutdown.Size = new System.Drawing.Size(100, 16);
            // 
            // Panel2_LabelRight
            // 
            this.Panel2_LabelRight.AutoSize = true;
            this.Panel2_LabelRight.Location = new System.Drawing.Point(135, 6);
            this.Panel2_LabelRight.Name = "Panel2_LabelRight";
            this.Panel2_LabelRight.Size = new System.Drawing.Size(16, 13);
            this.Panel2_LabelRight.TabIndex = 3;
            this.Panel2_LabelRight.Text = "...";
            // 
            // Panel2_ComboRight
            // 
            this.Panel2_ComboRight.FormattingEnabled = true;
            this.Panel2_ComboRight.Location = new System.Drawing.Point(4, 3);
            this.Panel2_ComboRight.Name = "Panel2_ComboRight";
            this.Panel2_ComboRight.Size = new System.Drawing.Size(124, 21);
            this.Panel2_ComboRight.TabIndex = 2;
            // 
            // Panel2_TreeViewRight
            // 
            this.Panel2_TreeViewRight.AllowDrop = true;
            this.Panel2_TreeViewRight.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel2_TreeViewRight.Location = new System.Drawing.Point(4, 30);
            this.Panel2_TreeViewRight.Name = "Panel2_TreeViewRight";
            this.Panel2_TreeViewRight.Size = new System.Drawing.Size(461, 406);
            this.Panel2_TreeViewRight.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel4,
            this.toolStripStatusLabel5,
            this.lbn_process,
            this.processBar});
            this.statusStrip1.Location = new System.Drawing.Point(5, 624);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(990, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.AutoSize = false;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(100, 17);
            this.toolStripStatusLabel1.Text = "Ctrl+C Copy";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.AutoSize = false;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(90, 17);
            this.toolStripStatusLabel2.Text = "Ctrl+X Cut";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.AutoSize = false;
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(100, 17);
            this.toolStripStatusLabel3.Text = "Ctrl+V Paste";
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.AutoSize = false;
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(90, 17);
            this.toolStripStatusLabel4.Text = "F2 Rename";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.AutoSize = false;
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(200, 17);
            this.toolStripStatusLabel5.Text = "Delete - DeleteToRecycle";
            // 
            // lbn_process
            // 
            this.lbn_process.AutoSize = false;
            this.lbn_process.Name = "lbn_process";
            this.lbn_process.Size = new System.Drawing.Size(250, 17);
            this.lbn_process.Text = "Tiến trình hệ thống";
            this.lbn_process.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // processBar
            // 
            this.processBar.BackColor = System.Drawing.Color.CornflowerBlue;
            this.processBar.Name = "processBar";
            this.processBar.Size = new System.Drawing.Size(100, 16);
            // 
            // TreeImageList
            // 
            this.TreeImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("TreeImageList.ImageStream")));
            this.TreeImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.TreeImageList.Images.SetKeyName(0, "BlueEmptyFolder.png");
            this.TreeImageList.Images.SetKeyName(1, "blueFolder.jpg");
            this.TreeImageList.Images.SetKeyName(2, "hard_disk.png");
            this.TreeImageList.Images.SetKeyName(3, "MyComuter.png");
            this.TreeImageList.Images.SetKeyName(4, "Desktop.png");
            this.TreeImageList.Images.SetKeyName(5, "Documents.png");
            this.TreeImageList.Images.SetKeyName(6, "Undo.png");
            // 
            // LargeImageList
            // 
            this.LargeImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("LargeImageList.ImageStream")));
            this.LargeImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.LargeImageList.Images.SetKeyName(0, "txt.png");
            this.LargeImageList.Images.SetKeyName(1, "pdf.png");
            this.LargeImageList.Images.SetKeyName(2, "htm.png");
            this.LargeImageList.Images.SetKeyName(3, "doc.png");
            this.LargeImageList.Images.SetKeyName(4, "exe.png");
            this.LargeImageList.Images.SetKeyName(5, "image.png");
            this.LargeImageList.Images.SetKeyName(6, "music.png");
            this.LargeImageList.Images.SetKeyName(7, "rar.png");
            this.LargeImageList.Images.SetKeyName(8, "ppt.png");
            this.LargeImageList.Images.SetKeyName(9, "mdb.png");
            this.LargeImageList.Images.SetKeyName(10, "xls.png");
            this.LargeImageList.Images.SetKeyName(11, "mp4.png");
            this.LargeImageList.Images.SetKeyName(12, "file.png");
            this.LargeImageList.Images.SetKeyName(13, "BlueEmptyFolder.png");
            this.LargeImageList.Images.SetKeyName(14, "blueFolder.jpg");
            this.LargeImageList.Images.SetKeyName(15, "hard_disk.png");
            this.LargeImageList.Images.SetKeyName(16, "MyComuter.png");
            this.LargeImageList.Images.SetKeyName(17, "Desktop.png");
            this.LargeImageList.Images.SetKeyName(18, "Documents.png");
            this.LargeImageList.Images.SetKeyName(19, "Undo.png");
            // 
            // SmallImageList
            // 
            this.SmallImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("SmallImageList.ImageStream")));
            this.SmallImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.SmallImageList.Images.SetKeyName(0, "txt");
            this.SmallImageList.Images.SetKeyName(1, "pdf");
            this.SmallImageList.Images.SetKeyName(2, "htm");
            this.SmallImageList.Images.SetKeyName(3, "doc");
            this.SmallImageList.Images.SetKeyName(4, "exe");
            this.SmallImageList.Images.SetKeyName(5, "image");
            this.SmallImageList.Images.SetKeyName(6, "music");
            this.SmallImageList.Images.SetKeyName(7, "rar");
            this.SmallImageList.Images.SetKeyName(8, "ppt");
            this.SmallImageList.Images.SetKeyName(9, "mdb");
            this.SmallImageList.Images.SetKeyName(10, "xls");
            this.SmallImageList.Images.SetKeyName(11, "mp4");
            this.SmallImageList.Images.SetKeyName(12, "file");
            this.SmallImageList.Images.SetKeyName(13, "BlueEmptyFolder");
            this.SmallImageList.Images.SetKeyName(14, "blueFolder");
            this.SmallImageList.Images.SetKeyName(15, "hard_disk");
            this.SmallImageList.Images.SetKeyName(16, "MyComuter");
            this.SmallImageList.Images.SetKeyName(17, "Desktop");
            this.SmallImageList.Images.SetKeyName(18, "Documents");
            this.SmallImageList.Images.SetKeyName(19, "Undo");
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(1000, 648);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.SplitContainer);
            this.Controls.Add(this.RibConMenu);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Total Commander";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.MainForm_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.MainForm_DragEnter);
            this.RibConMenu.ResumeLayout(false);
            this.RibConMenu.PerformLayout();
            this.ribbonPanel4.ResumeLayout(false);
            this.ribbonPanel3.ResumeLayout(false);
            this.ribbonPanel1.ResumeLayout(false);
            this.ribbonPanel2.ResumeLayout(false);
            this.SplitContainer.Panel1.ResumeLayout(false);
            this.SplitContainer.Panel1.PerformLayout();
            this.SplitContainer.Panel2.ResumeLayout(false);
            this.SplitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SplitContainer)).EndInit();
            this.SplitContainer.ResumeLayout(false);
            this.spc1_pan1_statusStrip.ResumeLayout(false);
            this.spc1_pan1_statusStrip.PerformLayout();
            this.spc1_pan2_statusStrip.ResumeLayout(false);
            this.spc1_pan2_statusStrip.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevComponents.DotNetBar.RibbonControl RibConMenu;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel1;
        private DevComponents.DotNetBar.RibbonBar ribOrganize;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel2;
        private DevComponents.DotNetBar.RibbonTabItem tabTools;
        private DevComponents.DotNetBar.RibbonTabItem tabView;
        private DevComponents.DotNetBar.ApplicationButton applicationButton1;
        private DevComponents.DotNetBar.ItemContainer itemContainer1;
        private DevComponents.DotNetBar.ItemContainer itemContainer4;
        private DevComponents.DotNetBar.ButtonItem buttonItem13;
        private DevComponents.DotNetBar.StyleManager StyleManage;
        private DevComponents.DotNetBar.ButtonItem btnNew;
        private DevComponents.DotNetBar.ButtonItem btnNewFolder;
        private DevComponents.DotNetBar.ButtonItem btnNewText;
        private DevComponents.DotNetBar.ButtonItem btnNewWord;
        private DevComponents.DotNetBar.ButtonItem btnNewExcel;
        private DevComponents.DotNetBar.ButtonItem btnCopy;
        private DevComponents.DotNetBar.ButtonItem btnPaste;
        private DevComponents.DotNetBar.ButtonItem btnCut;
        private DevComponents.DotNetBar.ItemContainer itemContainer5;
        private DevComponents.DotNetBar.ButtonItem btnCopyToFolder;
        private DevComponents.DotNetBar.ItemContainer itemContainer6;
        private DevComponents.DotNetBar.ButtonItem btnMoveToFolder;
        private DevComponents.DotNetBar.ItemContainer itemContainer7;
        private DevComponents.DotNetBar.ButtonItem btnDelete;
        private DevComponents.DotNetBar.ButtonItem btnRecycle;
        private DevComponents.DotNetBar.ButtonItem btnPerDel;
        private DevComponents.DotNetBar.RibbonBar ribbonBar3;
        private DevComponents.DotNetBar.ButtonItem btnLargeIcon;
        private DevComponents.DotNetBar.ButtonItem btnSmallIcon;
        private DevComponents.DotNetBar.ButtonItem btnListLayout;
        private DevComponents.DotNetBar.RibbonBar ribbonBar2;
        private DevComponents.DotNetBar.ButtonItem btnTreeView;
        private DevComponents.DotNetBar.ButtonItem btnListView;
        private DevComponents.DotNetBar.RibbonBar ribbonBar1;
        private DevComponents.DotNetBar.ButtonItem btnFind;
        private DevComponents.DotNetBar.ButtonItem btnRename;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel3;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel4;
        private DevComponents.DotNetBar.RibbonBar ribbonBar4;
        private DevComponents.DotNetBar.ButtonItem btnInfor;
        private DevComponents.DotNetBar.ButtonItem btnHelp;
        private DevComponents.DotNetBar.RibbonTabItem tabApp;
        private DevComponents.DotNetBar.RibbonTabItem tabHelp;
        private System.Windows.Forms.SplitContainer SplitContainer;
        private System.Windows.Forms.TreeView Panel1_TreeViewLeft;
        private System.Windows.Forms.TreeView Panel2_TreeViewRight;
        private System.Windows.Forms.ComboBox Panel1_ComboLeft;
        private System.Windows.Forms.ComboBox Panel2_ComboRight;
        private System.Windows.Forms.StatusStrip spc1_pan1_statusStrip;
        private System.Windows.Forms.Label Panel1_LabelLeft;
        private System.Windows.Forms.StatusStrip spc1_pan2_statusStrip;
        private System.Windows.Forms.Label Panel2_LabelRight;
        private System.Windows.Forms.ListView Panel1_ListViewLeft;
        private System.Windows.Forms.ListView Panel2_ListViewRight;
        private System.Windows.Forms.ToolStripStatusLabel Panel1_StatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel Panel2_StatusLabel;
        private System.Windows.Forms.FolderBrowserDialog fbdFolderDialog;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel lbn_process;
        private System.Windows.Forms.ToolStripProgressBar processBar;
        public System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar process_shutdown;
        private System.Windows.Forms.ToolStripStatusLabel spc1_pan2_statusLabel;
        private System.Windows.Forms.ColumnHeader colName;
        private System.Windows.Forms.ColumnHeader colSize;
        private System.Windows.Forms.ColumnHeader colDateCreated;
        private System.Windows.Forms.ColumnHeader colDateModified;
        private System.Windows.Forms.ColumnHeader colNameRight;
        private System.Windows.Forms.ColumnHeader colSizeRight;
        private System.Windows.Forms.ColumnHeader colDateCreatedRight;
        private System.Windows.Forms.ColumnHeader colDateModifiedRight;
        private System.Windows.Forms.ImageList TreeImageList;
        private System.Windows.Forms.ImageList LargeImageList;
        private System.Windows.Forms.ImageList SmallImageList;
        private DevComponents.DotNetBar.ItemContainer itemContainer3;
        private DevComponents.DotNetBar.ItemContainer itemContainer2;
        private DevComponents.DotNetBar.RibbonBar ribbonBar5;
        private DevComponents.DotNetBar.ItemContainer itemContainer8;
        private DevComponents.DotNetBar.ButtonItem btnCmd;
        private DevComponents.DotNetBar.ButtonItem btnTaskManage;
        private DevComponents.DotNetBar.ButtonItem btnNotepad;
    }
}

